import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { requireAuth, AuthRequest } from "./src/middleware/auth.ts";
import { db } from "./src/db/index.ts";
import { users, sessions, phoneNumbers, processingLogs } from "./src/db/schema.ts";
import { eq, and, desc, asc, sql, inArray, isNull, like } from "drizzle-orm";
import { startProcessing } from "./src/utils/background-processor.ts";
import { validatePhoneNumber } from "./src/utils/phone-validator.ts";
import { getValidationConfig, updateValidationConfig } from "./src/utils/validation-config.ts";

dotenv.config();

const app = express();
const PORT = 3000;

// Increase JSON limit to handle large lists of phone numbers (up to 10k)
app.use(express.json({ limit: "15mb" }));

// ------------------ API ROUTES ------------------

// 1. Handshake / Sync User Profile to database
app.post("/api/users/sync", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const email = req.user!.email || "user@phone-validator.com";

    // Determine default role
    let defaultRole = "Admin"; // Fallback default
    if (uid.includes("viewer")) {
      defaultRole = "Viewer";
    } else if (uid.includes("uploader") || uid.includes("editor")) {
      defaultRole = "Uploader";
    }

    // Upsert the user profile in PostgreSQL
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        role: defaultRole,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: { email },
      })
      .returning();

    res.json(result[0]);
  } catch (error: any) {
    console.error("Error syncing user:", error);
    res.status(500).json({ error: "Failed to sync user. Please try again." });
  }
});

// 2. Change Role (For testing/demoing role-based access control in the UI)
app.post("/api/users/role", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const { role } = req.body;

    if (!["Viewer", "Uploader", "Admin"].includes(role)) {
      return res.status(400).json({ error: "Invalid role specified" });
    }

    const result = await db
      .update(users)
      .set({ role })
      .where(eq(users.uid, uid))
      .returning();

    res.json(result[0]);
  } catch (error: any) {
    console.error("Error changing role:", error);
    res.status(500).json({ error: error.message });
  }
});

// Helper to fetch user's database role
async function getUserRole(uid: string): Promise<string> {
  const userList = await db.select().from(users).where(eq(users.uid, uid));
  return userList[0]?.role || "Viewer";
}

// 2.5. Validation Rules Configuration Endpoints
app.get("/api/validation/config", requireAuth, async (req: AuthRequest, res) => {
  res.json(getValidationConfig());
});

app.post("/api/validation/config", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const role = await getUserRole(uid);

    if (role !== "Admin" && role !== "Uploader") {
      return res.status(403).json({ error: "Access Denied: Only Admins and Uploaders can change validation configurations." });
    }

    const updated = updateValidationConfig(req.body);

    // Also write a system-wide log if possible or just log it to console
    console.log(`Validation configuration updated by user ${uid} (${role}):`, updated);
    res.json(updated);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Dashboard Statistics
app.get("/api/dashboard/stats", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;

    // Sum validation counts across all user's sessions
    const sumResult = await db
      .select({
        totalProcessed: sql<number>`COALESCE(SUM(${sessions.processedCount}), 0)`,
        totalValid: sql<number>`COALESCE(SUM(${sessions.validCount}), 0)`,
        totalInvalid: sql<number>`COALESCE(SUM(${sessions.invalidCount}), 0)`,
        totalDuplicate: sql<number>`COALESCE(SUM(${sessions.duplicateCount}), 0)`,
      })
      .from(sessions)
      .where(eq(sessions.userUid, uid));

    // Get all sessions
    const allSessions = await db
      .select()
      .from(sessions)
      .where(eq(sessions.userUid, uid));

    const totalSessions = allSessions.length;

    // Session Status Breakdowns
    const sessionsByStatus = {
      Draft: 0,
      Processing: 0,
      Paused: 0,
      Completed: 0,
      Cancelled: 0,
    };

    allSessions.forEach((s) => {
      if (s.status in sessionsByStatus) {
        sessionsByStatus[s.status as keyof typeof sessionsByStatus]++;
      }
    });

    // Country Distribution of VALID numbers across all user's sessions
    const countryRes = await db
      .select({
        country: phoneNumbers.countryCode,
        count: sql<number>`COUNT(*)`,
      })
      .from(phoneNumbers)
      .innerJoin(sessions, eq(phoneNumbers.sessionId, sessions.id))
      .where(
        and(
          eq(sessions.userUid, uid),
          eq(phoneNumbers.isValid, true)
        )
      )
      .groupBy(phoneNumbers.countryCode);

    const countryDistribution = countryRes.map((r) => ({
      country: r.country || "Unknown",
      count: Number(r.count),
    }));

    // Monthly trends (mocked base + dynamic stats)
    const monthlyTrends = [
      { name: "Feb", valid: 1200, invalid: 240 },
      { name: "Mar", valid: 2100, invalid: 380 },
      { name: "Apr", valid: 3400, invalid: 520 },
      { name: "May", valid: 5100, invalid: 840 },
      { name: "Jun", valid: 8900, invalid: 1100 },
      { name: "Jul (Active)", valid: Number(sumResult[0].totalValid), invalid: Number(sumResult[0].totalInvalid) },
    ];

    res.json({
      totalNumbersValidated: Number(sumResult[0].totalProcessed),
      totalValid: Number(sumResult[0].totalValid),
      totalInvalid: Number(sumResult[0].totalInvalid),
      totalDuplicatesCount: Number(sumResult[0].totalDuplicate),
      totalSessions,
      sessionsByStatus,
      monthlyTrends,
      countryDistribution,
    });
  } catch (error: any) {
    console.error("Error loading stats:", error);
    res.status(500).json({ error: error.message });
  }
});

// 4. Session Routes
app.get("/api/sessions", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const list = await db
      .select()
      .from(sessions)
      .where(eq(sessions.userUid, uid))
      .orderBy(desc(sessions.createdAt));
    res.json(list);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/sessions", requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    const role = await getUserRole(uid);

    if (role === "Viewer") {
      return res.status(403).json({ error: "Access Denied: Viewers cannot create sessions or upload files." });
    }

    const { name, rawNumbers } = req.body;

    if (!name || !Array.isArray(rawNumbers) || rawNumbers.length === 0) {
      return res.status(400).json({ error: "Missing session name or raw numbers." });
    }

    // 10,000 phone numbers limit enforcement
    if (rawNumbers.length > 10000) {
      return res.status(400).json({ error: "Max dataset size is 10,000 phone numbers." });
    }

    // Filter duplicates
    const uniqueRawNumbers = Array.from(new Set(rawNumbers.map((num) => String(num).trim()))).filter(Boolean);
    const duplicatesCount = rawNumbers.length - uniqueRawNumbers.length;

    // Create session in DB
    const sessionRes = await db
      .insert(sessions)
      .values({
        userUid: uid,
        name,
        status: "Draft",
        totalCount: uniqueRawNumbers.length,
        processedCount: 0,
        validCount: 0,
        invalidCount: 0,
        duplicateCount: duplicatesCount,
      })
      .returning();

    const newSession = sessionRes[0];

    // Insert phone numbers in chunks of 500 to keep it efficient
    const chunkSize = 500;
    for (let i = 0; i < uniqueRawNumbers.length; i += chunkSize) {
      const chunk = uniqueRawNumbers.slice(i, i + chunkSize);
      await db.insert(phoneNumbers).values(
        chunk.map((num) => ({
          sessionId: newSession.id,
          rawNumber: num,
        }))
      );
    }

    // Write initial logs
    await db.insert(processingLogs).values([
      {
        sessionId: newSession.id,
        level: "INFO",
        message: `Dataset imported successfully. Total items: ${rawNumbers.length}, Unique: ${uniqueRawNumbers.length}, Duplicates skipped: ${duplicatesCount}.`,
      },
    ]);

    res.json(newSession);
  } catch (error: any) {
    console.error("Error creating session:", error);
    res.status(500).json({ error: error.message });
  }
});

// Get session metadata
app.get("/api/sessions/:id", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));

    if (sessionList.length === 0) {
      return res.status(404).json({ error: "Session not found." });
    }

    res.json(sessionList[0]);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get paginated, sorted, and filtered numbers in a session
app.get("/api/sessions/:id/numbers", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const search = (req.query.search as string || "").trim();
    const isValidFilter = req.query.isValid as string || "all";
    const countryFilter = req.query.countryCode as string || "all";
    const whatsAppFilter = req.query.whatsApp as string || "all";
    const lineTypeFilter = req.query.lineType as string || "all";
    const tagFilter = req.query.tag as string || "";
    const sortBy = req.query.sortBy as string || "id";
    const sortOrder = req.query.sortOrder as string || "asc";

    const offset = (page - 1) * limit;

    // Verify session belongs to user
    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== req.user!.uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    // Build query conditions
    const conditions = [eq(phoneNumbers.sessionId, sessionId)];

    if (search) {
      conditions.push(
        sql`(${phoneNumbers.rawNumber} LIKE ${`%${search}%`} OR ${phoneNumbers.formattedNumber} LIKE ${`%${search}%`} OR ${phoneNumbers.notes} LIKE ${`%${search}%`} OR ${phoneNumbers.tags} LIKE ${`%${search}%`})`
      );
    }

    if (isValidFilter === "true") {
      conditions.push(eq(phoneNumbers.isValid, true));
    } else if (isValidFilter === "false") {
      conditions.push(eq(phoneNumbers.isValid, false));
    } else if (isValidFilter === "null") {
      conditions.push(isNull(phoneNumbers.isValid));
    }

    if (countryFilter !== "all") {
      conditions.push(eq(phoneNumbers.countryCode, countryFilter));
    }

    if (whatsAppFilter === "yes") {
      conditions.push(eq(phoneNumbers.hasWhatsApp, true));
    } else if (whatsAppFilter === "no") {
      conditions.push(eq(phoneNumbers.hasWhatsApp, false));
    } else if (whatsAppFilter === "unchecked") {
      conditions.push(isNull(phoneNumbers.hasWhatsApp));
    }

    if (lineTypeFilter !== "all") {
      conditions.push(eq(phoneNumbers.lineType, lineTypeFilter));
    }

    if (tagFilter) {
      conditions.push(like(phoneNumbers.tags, `%${tagFilter}%`));
    }

    const whereClause = and(...conditions);

    // Sorting definition
    let sortColumn: any = phoneNumbers.id;
    if (sortBy === "rawNumber") sortColumn = phoneNumbers.rawNumber;
    else if (sortBy === "formattedNumber") sortColumn = phoneNumbers.formattedNumber;
    else if (sortBy === "isValid") sortColumn = phoneNumbers.isValid;
    else if (sortBy === "validationError") sortColumn = phoneNumbers.validationError;
    else if (sortBy === "countryCode") sortColumn = phoneNumbers.countryCode;
    else if (sortBy === "hasWhatsApp") sortColumn = phoneNumbers.hasWhatsApp;

    const sortFn = sortOrder === "desc" ? desc(sortColumn) : asc(sortColumn);

    // Execute queries
    const list = await db
      .select()
      .from(phoneNumbers)
      .where(whereClause)
      .orderBy(sortFn)
      .limit(limit)
      .offset(offset);

    const countRes = await db
      .select({ count: sql<number>`count(*)` })
      .from(phoneNumbers)
      .where(whereClause);

    const total = Number(countRes[0].count);
    const totalPages = Math.ceil(total / limit);

    res.json({
      numbers: list,
      total,
      page,
      limit,
      totalPages,
    });
  } catch (error: any) {
    console.error("Error loading numbers:", error);
    res.status(500).json({ error: error.message });
  }
});

// Get session logs
app.get("/api/sessions/:id/logs", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const logs = await db
      .select()
      .from(processingLogs)
      .where(eq(processingLogs.sessionId, sessionId))
      .orderBy(desc(processingLogs.id));
    res.json(logs);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Session control action (start, pause, cancel)
app.post("/api/sessions/:id/action", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const { action } = req.body;
    const uid = req.user!.uid;
    const role = await getUserRole(uid);

    if (role === "Viewer") {
      return res.status(403).json({ error: "Access Denied: Viewers cannot manage or trigger validation runs." });
    }

    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    const currentSession = sessionList[0];

    if (action === "start") {
      // Start background processing
      await db
        .update(sessions)
        .set({ status: "Processing" })
        .where(eq(sessions.id, sessionId));

      await startProcessing(sessionId);
    } else if (action === "pause") {
      await db
        .update(sessions)
        .set({ status: "Paused" })
        .where(eq(sessions.id, sessionId));
    } else if (action === "cancel") {
      await db
        .update(sessions)
        .set({ status: "Cancelled" })
        .where(eq(sessions.id, sessionId));
    } else {
      return res.status(400).json({ error: "Invalid action." });
    }

    const updatedSession = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    res.json(updatedSession[0]);
  } catch (error: any) {
    console.error("Error executing action:", error);
    res.status(500).json({ error: error.message });
  }
});

// Session bulk action on selected phone numbers
app.post("/api/sessions/:id/bulk-action", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const { action, ids } = req.body; // ids is array of numbers ids
    const uid = req.user!.uid;
    const role = await getUserRole(uid);

    if (role === "Viewer") {
      return res.status(403).json({ error: "Access Denied: Viewers cannot make updates." });
    }

    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "No records selected." });
    }

    if (action === "delete") {
      // 1. Delete matching records
      await db.delete(phoneNumbers).where(
        and(
          eq(phoneNumbers.sessionId, sessionId),
          inArray(phoneNumbers.id, ids)
        )
      );

      // Recalculate total, valid, invalid numbers for this session
      const remainingNumbers = await db
        .select()
        .from(phoneNumbers)
        .where(eq(phoneNumbers.sessionId, sessionId));

      const totalCount = remainingNumbers.length;
      const processedCount = remainingNumbers.filter((n) => n.isValid !== null).length;
      const validCount = remainingNumbers.filter((n) => n.isValid === true).length;
      const invalidCount = remainingNumbers.filter((n) => n.isValid === false).length;

      await db
        .update(sessions)
        .set({
          totalCount,
          processedCount,
          validCount,
          invalidCount,
          updatedAt: new Date(),
        })
        .where(eq(sessions.id, sessionId));

      await db.insert(processingLogs).values({
        sessionId,
        level: "INFO",
        message: `Bulk action: Deleted ${ids.length} selected phone numbers manually.`,
      });
    } else if (action === "revalidate") {
      // Reset statuses
      await db
        .update(phoneNumbers)
        .set({
          isValid: null,
          formattedNumber: null,
          validationError: null,
          countryCode: null,
        })
        .where(
          and(
            eq(phoneNumbers.sessionId, sessionId),
            inArray(phoneNumbers.id, ids)
          )
        );

      // Re-calculate session totals
      const remainingNumbers = await db
        .select()
        .from(phoneNumbers)
        .where(eq(phoneNumbers.sessionId, sessionId));

      const processedCount = remainingNumbers.filter((n) => n.isValid !== null).length;
      const validCount = remainingNumbers.filter((n) => n.isValid === true).length;
      const invalidCount = remainingNumbers.filter((n) => n.isValid === false).length;

      await db
        .update(sessions)
        .set({
          processedCount,
          validCount,
          invalidCount,
          status: "Processing",
          updatedAt: new Date(),
        })
        .where(eq(sessions.id, sessionId));

      await db.insert(processingLogs).values({
        sessionId,
        level: "INFO",
        message: `Bulk action: Reset and queued ${ids.length} numbers for re-validation.`,
      });

      // Trigger processing worker
      await startProcessing(sessionId);
    } else {
      return res.status(400).json({ error: "Invalid bulk action." });
    }

    const updatedSession = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    res.json(updatedSession[0]);
  } catch (error: any) {
    console.error("Error executing bulk action:", error);
    res.status(500).json({ error: error.message });
  }
});

// Delete a session completely
app.delete("/api/sessions/:id", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const uid = req.user!.uid;
    const role = await getUserRole(uid);

    if (role !== "Admin") {
      return res.status(403).json({ error: "Access Denied: Only Admins can delete sessions." });
    }

    // Verify session belongs to user
    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    await db.delete(sessions).where(eq(sessions.id, sessionId));
    res.json({ success: true, message: "Session and all associated data deleted." });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Export Session Results (CSV, TXT, Excel/TSV format)
app.get("/api/sessions/:id/export", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const format = req.query.format as string || "csv"; // csv, txt, xls
    const filter = req.query.filter as string || "all"; // all, valid, invalid

    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== req.user!.uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    const session = sessionList[0];

    // Query all records for export
    const conditions = [eq(phoneNumbers.sessionId, sessionId)];
    if (filter === "valid") {
      conditions.push(eq(phoneNumbers.isValid, true));
    } else if (filter === "invalid") {
      conditions.push(eq(phoneNumbers.isValid, false));
    }

    const numbers = await db
      .select()
      .from(phoneNumbers)
      .where(and(...conditions))
      .orderBy(asc(phoneNumbers.id));

    const safeName = session.name.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();

    if (format === "txt") {
      // Export simple TXT: one formatted number per line
      const content = numbers
        .map((n) => n.formattedNumber || n.rawNumber)
        .filter(Boolean)
        .join("\n");

      res.setHeader("Content-Disposition", `attachment; filename="${safeName}_export.txt"`);
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.send(content);
    } else if (format === "xls" || format === "excel") {
      // Export TSV which opens flawlessly in Excel
      const headers = [
        "ID",
        "Raw Number",
        "Formatted Number",
        "Is Valid",
        "Error Message",
        "Country Code",
        "Line Type",
        "Timezone",
        "WhatsApp Registered",
        "WhatsApp Display Name",
        "WhatsApp About Status",
        "Is Business",
        "Import Date"
      ];
      const rows = numbers.map((n) => [
        n.id,
        n.rawNumber,
        n.formattedNumber || "",
        n.isValid === null ? "Pending" : n.isValid ? "Valid" : "Invalid",
        n.validationError || "",
        n.countryCode || "",
        n.lineType || "",
        n.timezone || "",
        n.hasWhatsApp === null ? "Unchecked" : n.hasWhatsApp ? "Yes" : "No",
        n.waProfileName || "",
        n.waAboutText || "",
        n.waIsBusiness === null ? "" : n.waIsBusiness ? "Yes" : "No",
        n.createdAt ? new Date(n.createdAt).toISOString() : "",
      ]);

      const content = [headers.join("\t"), ...rows.map((r) => r.join("\t"))].join("\r\n");

      res.setHeader("Content-Disposition", `attachment; filename="${safeName}_export.xls"`);
      res.setHeader("Content-Type", "application/vnd.ms-excel; charset=utf-8");
      return res.send(content);
    } else {
      // Default standard CSV
      const headers = [
        "ID",
        "Raw Number",
        "Formatted Number",
        "Is Valid",
        "Error Message",
        "Country Code",
        "Line Type",
        "Timezone",
        "WhatsApp Registered",
        "WhatsApp Display Name",
        "WhatsApp About Status",
        "Is Business",
        "Import Date"
      ];
      const escapeCsvField = (field: any) => {
        const str = String(field || "");
        if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      };

      const rows = numbers.map((n) => [
        n.id,
        n.rawNumber,
        n.formattedNumber || "",
        n.isValid === null ? "Pending" : n.isValid ? "Valid" : "Invalid",
        n.validationError || "",
        n.countryCode || "",
        n.lineType || "",
        n.timezone || "",
        n.hasWhatsApp === null ? "Unchecked" : n.hasWhatsApp ? "Yes" : "No",
        n.waProfileName || "",
        n.waAboutText || "",
        n.waIsBusiness === null ? "" : n.waIsBusiness ? "Yes" : "No",
        n.createdAt ? new Date(n.createdAt).toISOString() : "",
      ]);

      const content = [
        headers.join(","),
        ...rows.map((r) => r.map(escapeCsvField).join(",")),
      ].join("\r\n");

      res.setHeader("Content-Disposition", `attachment; filename="${safeName}_export.csv"`);
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      return res.send(content);
    }
  } catch (error: any) {
    console.error("Export error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Export Session Diagnostic Logs as text file
app.get("/api/sessions/:id/logs-export", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== req.user!.uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    const session = sessionList[0];
    const logs = await db
      .select()
      .from(processingLogs)
      .where(eq(processingLogs.sessionId, sessionId))
      .orderBy(asc(processingLogs.id));

    const content = logs
      .map((l) => `[${l.timestamp ? new Date(l.timestamp).toISOString() : ""}] [${l.level}] ${l.message}`)
      .join("\n");

    const safeName = session.name.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}_diagnostics_log.txt"`);
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    return res.send(content);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 8. Single number quick validation sandbox
app.post("/api/validation/single", requireAuth, async (req: AuthRequest, res) => {
  try {
    const { rawNumber } = req.body;
    if (!rawNumber) {
      return res.status(400).json({ error: "Phone number is required." });
    }

    const valResult = validatePhoneNumber(rawNumber);
    
    // Simulate WhatsApp check if valid
    let whatsAppResult = null;
    if (valResult.isValid) {
      const config = getValidationConfig();
      const hasWhatsApp = Math.random() > 0.35; // 65% WA rate
      if (hasWhatsApp) {
        const names = ["Alex Rivera", "Sophia Patel", "Marcus Dupont", "Yuki Tanaka", "Elena Rostova", "Liam O'Connor", "Amara Okafor"];
        const statuses = ["Hey there! I am using WhatsApp.", "Busy", "At work", "Available", "Urgent calls only", "☕ Coffee & Code"];
        const pics = [
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80",
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80",
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80"
        ];
        
        whatsAppResult = {
          hasWhatsApp: true,
          waProfileName: names[Math.floor(Math.random() * names.length)],
          waAboutText: statuses[Math.floor(Math.random() * statuses.length)],
          waProfilePic: pics[Math.floor(Math.random() * pics.length)],
          waIsBusiness: Math.random() > 0.75,
          waCheckedAt: new Date().toISOString()
        };
      } else {
        whatsAppResult = {
          hasWhatsApp: false,
          waProfileName: null,
          waAboutText: null,
          waProfilePic: null,
          waIsBusiness: false,
          waCheckedAt: new Date().toISOString()
        };
      }
    }

    // Predict timezone and line type based on country rules
    const lineTypes = ["Mobile", "Mobile", "Mobile", "Landline", "VOIP"];
    const predictedLineType = valResult.isValid 
      ? lineTypes[Math.floor(Math.random() * lineTypes.length)] 
      : null;

    const timezones: Record<string, string> = {
      "US/CA": "EST (UTC-5)",
      "UK": "GMT (UTC+0)",
      "DE": "CET (UTC+1)",
      "FR": "CET (UTC+1)",
      "IN": "IST (UTC+5.5)",
      "AU": "AEST (UTC+10)"
    };
    const predictedTimezone = valResult.isValid
      ? timezones[valResult.countryCode] || "GMT (UTC+0)"
      : null;

    res.json({
      ...valResult,
      lineType: predictedLineType,
      timezone: predictedTimezone,
      whatsApp: whatsAppResult
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 9. Update number custom notes and tags
app.post("/api/numbers/:id/metadata", requireAuth, async (req: AuthRequest, res) => {
  try {
    const id = parseInt(req.params.id);
    const { notes, tags } = req.body;

    const updated = await db
      .update(phoneNumbers)
      .set({
        notes: notes !== undefined ? notes : undefined,
        tags: tags !== undefined ? tags : undefined,
      })
      .where(eq(phoneNumbers.id, id))
      .returning();

    if (updated.length === 0) {
      return res.status(404).json({ error: "Number not found" });
    }

    res.json(updated[0]);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 10. Bulk actions on numbers
app.post("/api/sessions/:id/numbers/bulk", requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessionId = parseInt(req.params.id);
    const { ids, action, tagValue } = req.body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "Selected IDs must be a non-empty array" });
    }

    // Verify session belongs to user
    const sessionList = await db.select().from(sessions).where(eq(sessions.id, sessionId));
    if (sessionList.length === 0 || sessionList[0].userUid !== req.user!.uid) {
      return res.status(404).json({ error: "Session not found." });
    }

    if (action === "delete") {
      // Delete rows
      await db.delete(phoneNumbers).where(and(eq(phoneNumbers.sessionId, sessionId), inArray(phoneNumbers.id, ids)));
    } else if (action === "tag") {
      // Update tags
      await db
        .update(phoneNumbers)
        .set({ tags: tagValue || "" })
        .where(and(eq(phoneNumbers.sessionId, sessionId), inArray(phoneNumbers.id, ids)));
    } else if (action === "blacklist") {
      // Get numbers first to add them to blacklist config
      const listToBlacklist = await db
        .select()
        .from(phoneNumbers)
        .where(and(eq(phoneNumbers.sessionId, sessionId), inArray(phoneNumbers.id, ids)));

      const blacklistNumbers = listToBlacklist.map(n => n.formattedNumber || n.rawNumber).filter(Boolean);
      
      const config = getValidationConfig();
      const updatedBlacklist = Array.from(new Set([...config.blacklistNumbers, ...blacklistNumbers]));
      updateValidationConfig({ blacklistNumbers: updatedBlacklist });

      // Mark as invalid on DB
      await db
        .update(phoneNumbers)
        .set({
          isValid: false,
          validationError: "Blacklisted number (Global DNC List)"
        })
        .where(and(eq(phoneNumbers.sessionId, sessionId), inArray(phoneNumbers.id, ids)));
    } else {
      return res.status(400).json({ error: "Invalid action specified." });
    }

    // Recalculate session statistics
    const allNums = await db.select().from(phoneNumbers).where(eq(phoneNumbers.sessionId, sessionId));
    const totalCount = allNums.length;
    const processedCount = allNums.filter(n => n.isValid !== null).length;
    const validCount = allNums.filter(n => n.isValid === true).length;
    const invalidCount = allNums.filter(n => n.isValid === false).length;

    const updatedSession = await db
      .update(sessions)
      .set({
        totalCount,
        processedCount,
        validCount,
        invalidCount,
        updatedAt: new Date(),
      })
      .where(eq(sessions.id, sessionId))
      .returning();

    // Log the bulk operation
    await db.insert(processingLogs).values({
      sessionId,
      level: "INFO",
      message: `Executed bulk action: ${action.toUpperCase()} on ${ids.length} item(s). Session counts updated.`
    });

    res.json({ success: true, session: updatedSession[0] });
  } catch (error: any) {
    console.error("Bulk action error:", error);
    res.status(500).json({ error: error.message });
  }
});

// ------------------ VITE / STATIC SERVING ------------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
