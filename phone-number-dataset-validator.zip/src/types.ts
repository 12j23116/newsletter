export type UserRole = "Viewer" | "Uploader" | "Admin";

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  createdAt?: string;
}

export type SessionStatus = "Draft" | "Processing" | "Paused" | "Completed" | "Cancelled";

export interface Session {
  id: number;
  userUid: string;
  name: string;
  status: SessionStatus;
  totalCount: number;
  processedCount: number;
  validCount: number;
  invalidCount: number;
  duplicateCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface PhoneNumber {
  id: number;
  sessionId: number;
  rawNumber: string;
  formattedNumber: string | null;
  isValid: boolean | null;
  validationError: string | null;
  countryCode: string | null;
  hasWhatsApp?: boolean | null;
  waCheckedAt?: string | null;
  waProfileName?: string | null;
  waAboutText?: string | null;
  waProfilePic?: string | null;
  waIsBusiness?: boolean | null;
  lineType?: string | null;
  timezone?: string | null;
  tags?: string | null;
  notes?: string | null;
  createdAt: string;
}

export interface ProcessingLog {
  id: number;
  sessionId: number;
  level: "INFO" | "WARNING" | "ERROR";
  message: string;
  timestamp: string;
}

export interface DashboardStats {
  totalNumbersValidated: number;
  totalValid: number;
  totalInvalid: number;
  totalDuplicatesCount: number;
  totalSessions: number;
  sessionsByStatus: {
    Draft: number;
    Processing: number;
    Paused: number;
    Completed: number;
    Cancelled: number;
  };
  monthlyTrends: Array<{
    name: string;
    valid: number;
    invalid: number;
  }>;
  countryDistribution: Array<{
    country: string;
    count: number;
  }>;
}
