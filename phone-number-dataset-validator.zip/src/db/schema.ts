import { pgTable, text, timestamp, integer, boolean, serial } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// 1. Users Table (keyed by Firebase Auth UID)
export const users = pgTable("users", {
  uid: text("uid").primaryKey(),
  email: text("email").notNull(),
  role: text("role").notNull().default("Viewer"), // Viewer, Editor, Admin
  createdAt: timestamp("created_at").defaultNow(),
});

// 2. Validation Sessions
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userUid: text("user_uid")
    .references(() => users.uid, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("Draft"), // "Draft", "Processing", "Paused", "Completed", "Cancelled"
  totalCount: integer("total_count").notNull().default(0),
  processedCount: integer("processed_count").notNull().default(0),
  validCount: integer("valid_count").notNull().default(0),
  invalidCount: integer("invalid_count").notNull().default(0),
  duplicateCount: integer("duplicate_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// 3. Phone Numbers
export const phoneNumbers = pgTable("phone_numbers", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id")
    .references(() => sessions.id, { onDelete: "cascade" })
    .notNull(),
  rawNumber: text("raw_number").notNull(),
  formattedNumber: text("formatted_number"),
  isValid: boolean("is_valid"),
  validationError: text("validation_error"),
  countryCode: text("country_code"),
  hasWhatsApp: boolean("has_whatsapp"),
  waCheckedAt: timestamp("wa_checked_at"),
  waProfileName: text("wa_profile_name"),
  waAboutText: text("wa_about_text"),
  waProfilePic: text("wa_profile_pic"),
  waIsBusiness: boolean("wa_is_business"),
  lineType: text("line_type"),
  timezone: text("timezone"),
  tags: text("tags"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// 4. Detailed Processing Logs
export const processingLogs = pgTable("processing_logs", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id")
    .references(() => sessions.id, { onDelete: "cascade" })
    .notNull(),
  level: text("level").notNull(), // "INFO", "WARNING", "ERROR"
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// --- Relations ---

export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(sessions),
}));

export const sessionsRelations = relations(sessions, ({ one, many }) => ({
  user: one(users, {
    fields: [sessions.userUid],
    references: [users.uid],
  }),
  phoneNumbers: many(phoneNumbers),
  logs: many(processingLogs),
}));

export const phoneNumbersRelations = relations(phoneNumbers, ({ one }) => ({
  session: one(sessions, {
    fields: [phoneNumbers.sessionId],
    references: [sessions.id],
  }),
}));

export const processingLogsRelations = relations(processingLogs, ({ one }) => ({
  session: one(sessions, {
    fields: [processingLogs.sessionId],
    references: [sessions.id],
  }),
}));
