import React, { useState, useEffect, useCallback } from "react";
import Login from "./components/Login.tsx";
import Dashboard from "./components/Dashboard.tsx";
import SessionUpload from "./components/SessionUpload.tsx";
import SessionDetail from "./components/SessionDetail.tsx";
import RulesModal from "./components/RulesModal.tsx";
import WhatsAppConfigModal from "./components/WhatsAppConfigModal.tsx";
import { Session, DashboardStats, UserRole } from "./types.ts";
import {
  Phone,
  ShieldAlert,
  LogOut,
  Moon,
  Sun,
  LayoutGrid,
  FileSpreadsheet,
  RotateCw,
  UserCheck,
  SlidersHorizontal,
  MessageSquare,
} from "lucide-react";

export default function App() {
  // Auth state
  const [token, setToken] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string>("");
  const [userRole, setUserRole] = useState<UserRole>("Viewer");
  const [isDemo, setIsDemo] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  // App Layout state
  const [activeView, setActiveView] = useState<"dashboard" | "upload" | "detail">("dashboard");
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Datasets and Stats
  const [sessions, setSessions] = useState<Session[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalNumbersValidated: 0,
    totalValid: 0,
    totalInvalid: 0,
    totalDuplicatesCount: 0,
    totalSessions: 0,
    sessionsByStatus: { Draft: 0, Processing: 0, Paused: 0, Completed: 0, Cancelled: 0 },
    monthlyTrends: [],
    countryDistribution: [],
  });

  const [loading, setLoading] = useState(false);
  const [syncingRole, setSyncingRole] = useState(false);

  // Load active sessions and statistics
  const loadDashboardData = useCallback(async (authToken: string) => {
    if (!authToken) return;
    setLoading(true);
    try {
      // 1. Fetch Stats
      const statsRes = await fetch("/api/dashboard/stats", {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      // 2. Fetch Sessions list
      const sessionsRes = await fetch("/api/sessions", {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (sessionsRes.ok) {
        const sessionsData = await sessionsRes.json();
        setSessions(sessionsData);
      }
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Sync token check on startup
  useEffect(() => {
    const savedToken = sessionStorage.getItem("auth_token");
    const savedEmail = sessionStorage.getItem("auth_email");
    const savedDemo = sessionStorage.getItem("is_demo") === "true";
    const savedRole = sessionStorage.getItem("demo_role") as UserRole;

    if (savedToken && savedEmail) {
      setToken(savedToken);
      setUserEmail(savedEmail);
      setIsDemo(savedDemo);
      if (savedRole) {
        setUserRole(savedRole);
      }
      loadDashboardData(savedToken);
    }
  }, [loadDashboardData]);

  // Dark/Light Theme Handler
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [darkMode]);

  // Handle successful login (Google popup or sandbox bypass)
  const handleLoginSuccess = async (
    userToken: string,
    email: string,
    demoAuth: boolean,
    demoRole?: string
  ) => {
    setLoading(true);
    
    // Save in sessionStorage so page refreshes don't drop auth
    sessionStorage.setItem("auth_token", userToken);
    sessionStorage.setItem("auth_email", email);
    sessionStorage.setItem("is_demo", demoAuth ? "true" : "false");
    
    setToken(userToken);
    setUserEmail(email);
    setIsDemo(demoAuth);

    try {
      // 1. Handshake with backend to register/sync profile
      const syncRes = await fetch("/api/users/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      });

      if (syncRes.ok) {
        const profile = await syncRes.json();
        setUserRole(profile.role as UserRole);

        // 2. If it is a demo profile, also synchronize selected demo role explicitly
        const targetRole = (demoRole || profile.role) as UserRole;
        if (demoAuth && demoRole) {
          await fetch("/api/users/role", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${userToken}`,
            },
            body: JSON.stringify({ role: targetRole }),
          });
          setUserRole(targetRole);
          sessionStorage.setItem("demo_role", targetRole);
        }
      }
    } catch (err) {
      console.error("Sync profile failed on startup:", err);
    }

    // Load initial listings
    await loadDashboardData(userToken);
  };

  // Switch role dynamically from the UI for demo/testing RBAC restrictions
  const handleRoleChange = async (newRole: UserRole) => {
    if (!token) return;
    setSyncingRole(true);
    try {
      const res = await fetch("/api/users/role", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ role: newRole }),
      });

      if (res.ok) {
        setUserRole(newRole);
        sessionStorage.setItem("demo_role", newRole);
        
        // Refresh stats
        await loadDashboardData(token);
      }
    } catch (err) {
      console.error("Failed to update role:", err);
    } finally {
      setSyncingRole(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.clear();
    setToken(null);
    setUserEmail("");
    setUserRole("Viewer");
    setIsDemo(false);
    setActiveView("dashboard");
    setActiveSessionId(null);
  };

  // API Call: Create new session
  const handleUploadSuccess = async (name: string, rawNumbers: string[]) => {
    if (!token) return;
    const res = await fetch("/api/sessions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ name, rawNumbers }),
    });

    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || "Failed to save dataset.");
    }

    const newSession = await res.json();
    
    // Refresh lists
    await loadDashboardData(token);

    // Open detail page immediately so they can trigger and watch processing
    setActiveSessionId(newSession.id);
    setActiveView("detail");
  };

  // API Call: Run action (start, pause, cancel) from dashboard
  const handleTriggerAction = async (sessionId: number, action: "start" | "pause" | "cancel") => {
    if (!token) return;
    try {
      const res = await fetch(`/api/sessions/${sessionId}/action`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action }),
      });

      if (res.ok) {
        await loadDashboardData(token);
      } else {
        const err = await res.json();
        alert(err.error || "Action failed");
      }
    } catch (err) {
      console.error("Failed to execute action:", err);
    }
  };

  // API Call: Delete dataset completely
  const handleDeleteSession = async (sessionId: number) => {
    if (!token) return;
    if (userRole === "Viewer") {
      alert("Permission Denied: Viewers cannot delete sessions.");
      return;
    }
    if (!window.confirm("Are you sure you want to delete this validation session and all numbers?")) {
      return;
    }

    try {
      const res = await fetch(`/api/sessions/${sessionId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        if (activeSessionId === sessionId) {
          setActiveView("dashboard");
          setActiveSessionId(null);
        }
        await loadDashboardData(token);
      } else {
        const data = await res.json();
        alert(data.error || "Delete failed");
      }
    } catch (err) {
      console.error("Failed to delete session:", err);
    }
  };

  if (!token) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans transition-colors duration-200">
      {/* Header Navbar */}
      <header className="border-b bg-slate-900 border-slate-800 sticky top-0 z-40 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center shadow-md shadow-blue-500/20">
              <span className="text-white font-bold text-base">V</span>
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white leading-tight">Validator Pro</h1>
              <span className="block text-[9px] text-slate-400 font-mono leading-none">E.164 BULK ENGINE</span>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-1.5 text-xs font-semibold">
            <button
              onClick={() => {
                setActiveView("dashboard");
                setActiveSessionId(null);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-md transition duration-150 cursor-pointer ${
                activeView === "dashboard"
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Dashboard
            </button>
            {userRole !== "Viewer" && (
              <button
                onClick={() => {
                  setActiveView("upload");
                  setActiveSessionId(null);
                }}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-md transition duration-150 cursor-pointer ${
                  activeView === "upload"
                    ? "bg-blue-600 text-white"
                    : "text-slate-400 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5" /> Data Import
              </button>
            )}
          </nav>

          {/* Right Side Settings & Controls */}
          <div className="flex items-center gap-3">
            {/* Real-time Loading spinner */}
            {loading && <RotateCw className="w-4 h-4 text-blue-400 animate-spin" />}

            {/* Interactive RBAC Switcher */}
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border bg-slate-800 border-slate-700/80">
              <UserCheck className="w-3.5 h-3.5 text-slate-400" />
              <div className="flex flex-col text-[10px] leading-none">
                <span className="text-slate-500 font-semibold uppercase tracking-wider font-mono text-[8px]">Active Role</span>
                <select
                  value={userRole}
                  onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                  disabled={syncingRole}
                  className="bg-transparent text-slate-200 font-bold outline-none text-[11px] cursor-pointer focus:text-blue-400 mt-0.5 border-none p-0"
                >
                  <option value="Admin" className="bg-slate-800">Admin (Full)</option>
                  <option value="Uploader" className="bg-slate-800">Uploader (Write)</option>
                  <option value="Viewer" className="bg-slate-800">Viewer (Read)</option>
                </select>
              </div>
            </div>

            {/* Config Rules button (Admins & Uploaders) */}
            <button
              onClick={() => setIsRulesModalOpen(true)}
              title="Configure Validation Rules"
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>

            {/* WhatsApp Gateway configurations */}
            <button
              onClick={() => setIsWhatsAppModalOpen(true)}
              title="Configure WhatsApp API Gateway"
              className="p-2 rounded-lg bg-emerald-900/40 hover:bg-emerald-900/60 border border-emerald-700/50 text-emerald-300 hover:text-white transition cursor-pointer flex items-center justify-center"
            >
              <MessageSquare className="w-4 h-4" />
            </button>

            {/* Logout & Profile */}
            <div className="hidden lg:flex flex-col text-right">
              <span className="text-[10px] text-slate-300 font-mono leading-none max-w-[130px] truncate" title={userEmail}>
                {userEmail}
              </span>
              <span className="text-[9px] text-slate-500 mt-0.5 font-semibold">
                {isDemo ? "Sandbox Mode" : "Google Authenticated"}
              </span>
            </div>

            <button
              onClick={handleLogout}
              title="Sign Out"
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === "dashboard" ? (
          <Dashboard
            stats={stats}
            sessions={sessions}
            userRole={userRole}
            onOpenSession={(id) => {
              setActiveSessionId(id);
              setActiveView("detail");
            }}
            onDeleteSession={handleDeleteSession}
            onTriggerAction={handleTriggerAction}
            onNavigateToUpload={() => setActiveView("upload")}
          />
        ) : activeView === "upload" ? (
          <SessionUpload
            onBackToDashboard={() => setActiveView("dashboard")}
            onUploadSuccess={handleUploadSuccess}
          />
        ) : activeView === "detail" && activeSessionId !== null ? (
          <SessionDetail
            sessionId={activeSessionId}
            userRole={userRole}
            onBackToDashboard={() => {
              setActiveView("dashboard");
              setActiveSessionId(null);
              loadDashboardData(token);
            }}
            onDeleteSession={handleDeleteSession}
          />
        ) : (
          <div className="p-12 text-center text-slate-400">View not found</div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 py-4 text-center text-[10px] text-slate-500 font-mono bg-white">
        <p>&copy; 2026 Validator Pro Inc. Standard E.164 formatting & audit trailing compliance. All rights reserved.</p>
      </footer>

      {/* Validation Rules Settings Modal */}
      <RulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
        token={token}
        userRole={userRole}
      />

      {/* WhatsApp Gateway Settings Modal */}
      <WhatsAppConfigModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => setIsWhatsAppModalOpen(false)}
        token={token}
        userRole={userRole}
      />
    </div>
  );
}
