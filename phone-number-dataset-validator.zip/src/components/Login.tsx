import React, { useState } from "react";
import { signInWithPopup } from "firebase/auth";
import { auth, googleAuthProvider } from "../lib/firebase.ts";
import { Sparkles, Phone, ShieldCheck, HelpCircle } from "lucide-react";

interface LoginProps {
  onLoginSuccess: (token: string, userEmail: string, isDemo: boolean, demoRole?: string) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const token = await result.user.getIdToken();
      onLoginSuccess(token, result.user.email || "user@phone-validator.com", false);
    } catch (err: any) {
      console.error("Google Auth failed:", err);
      setError(
        "Google Sign-In popup blocked or cancelled. For testing in sandboxed environments, please use the quick 'Demo Mode' profiles below."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = (role: "Admin" | "Uploader" | "Viewer") => {
    setLoading(true);
    const mockToken = `DEMO_TOKEN_${role.toUpperCase()}`;
    const mockEmail = role === "Viewer" ? "guest@phone-validator.com" : `demo_${role.toLowerCase()}@phone-validator.com`;
    setTimeout(() => {
      onLoginSuccess(mockToken, mockEmail, true, role);
      setLoading(false);
    }, 400);
  };

  return (
    <div id="login_screen" className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-8 text-center bg-gradient-to-br from-blue-600 to-indigo-600 text-white relative">
          <div className="absolute top-4 right-4 bg-white/10 text-white text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full">
            v1.0.0
          </div>
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20 shadow-sm">
            <Phone className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold font-sans tracking-tight">Validator Pro</h1>
          <p className="text-xs text-blue-50 mt-2 font-medium max-w-sm mx-auto">
            Secure, scalable E.164 phone dataset validation and E.164 standardization engine.
          </p>
        </div>

        {/* Content */}
        <div className="p-8">
          {error && (
            <div className="mb-6 p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg leading-relaxed shadow-sm">
              {error}
            </div>
          )}

          {/* Quick Access/Guest Option */}
          <button
            onClick={() => handleDemoLogin("Viewer")}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 px-4 rounded-xl shadow-md transition-all duration-200 disabled:opacity-50 cursor-pointer text-sm mb-4"
          >
            Explore as Guest (No Login Required)
          </button>

          {/* Real Auth Option */}
          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-50 text-slate-800 font-semibold py-3 px-4 rounded-xl border border-slate-200 shadow-sm transition-all duration-200 disabled:opacity-50 cursor-pointer text-sm"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Sign in with Google
          </button>

          <div className="relative my-6 text-center">
            <span className="absolute inset-x-0 top-1/2 -translate-y-1/2 border-t border-slate-200"></span>
            <span className="relative bg-white px-3 text-xs text-slate-400 font-mono font-medium">
              OR TEST ROLE RESTRICTIONS
            </span>
          </div>

          {/* Sandbox Demo Login Options */}
          <div className="space-y-3">
            <div className="text-center text-xs text-slate-500 font-medium mb-2 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
              Iframe-safe Sandbox Login Profiles
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleDemoLogin("Admin")}
                disabled={loading}
                className="bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-semibold py-2.5 px-1 rounded-xl text-xs transition duration-200 cursor-pointer flex flex-col items-center justify-center gap-1 shadow-sm"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Admin
              </button>
              <button
                onClick={() => handleDemoLogin("Uploader")}
                disabled={loading}
                className="bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 font-semibold py-2.5 px-1 rounded-xl text-xs transition duration-200 cursor-pointer flex flex-col items-center justify-center gap-1 shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-blue-600" />
                Uploader
              </button>
              <button
                onClick={() => handleDemoLogin("Viewer")}
                disabled={loading}
                className="bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 font-semibold py-2.5 px-1 rounded-xl text-xs transition duration-200 cursor-pointer flex flex-col items-center justify-center gap-1 shadow-sm"
              >
                <HelpCircle className="w-4 h-4 text-amber-600" />
                Viewer
              </button>
            </div>

            <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed font-mono">
              <p className="font-bold text-slate-700">Role Capabilities:</p>
              <ul className="list-disc pl-4 mt-1 space-y-1">
                <li><span className="text-emerald-600 font-bold">Admin</span>: Full access (full validation configs, upload, delete)</li>
                <li><span className="text-blue-600 font-bold">Uploader</span>: Upload datasets and run/pause/cancel validations</li>
                <li><span className="text-amber-600 font-bold">Viewer</span>: Read-only dashboards and exports (no upload/runs)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
