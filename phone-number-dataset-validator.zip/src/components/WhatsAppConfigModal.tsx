import React, { useState, useEffect } from "react";
import { X, MessageSquare, CheckCircle2, ShieldAlert, Key, QrCode, Sliders, Play, RefreshCw, Smartphone } from "lucide-react";
import { UserRole } from "../types.ts";

interface WhatsAppConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  userRole: UserRole;
}

export default function WhatsAppConfigModal({ isOpen, onClose, token, userRole }: WhatsAppConfigModalProps) {
  const [whatsAppCheckEnabled, setWhatsAppCheckEnabled] = useState(true);
  const [useWhatsAppSimulation, setUseWhatsAppSimulation] = useState(true);
  const [whatsAppApiUrl, setWhatsAppApiUrl] = useState("");
  const [whatsAppApiKey, setWhatsAppApiKey] = useState("");
  const [whatsAppInstanceName, setWhatsAppInstanceName] = useState("validator-pro");
  
  const [whatsAppDelayMin, setWhatsAppDelayMin] = useState(2);
  const [whatsAppDelayMax, setWhatsAppDelayMax] = useState(6);
  const [maxChecksPerHour, setMaxChecksPerHour] = useState(300);

  // QR Login State
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [qrStatus, setQrStatus] = useState<"idle" | "generating" | "waiting" | "connecting" | "connected">("idle");
  const [instanceStatus, setInstanceStatus] = useState<string>("Disconnected");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    if (isOpen && token) {
      fetchConfig();
    }
  }, [isOpen, token]);

  const fetchConfig = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/validation/config", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const config = await res.json();
        setWhatsAppCheckEnabled(config.whatsAppCheckEnabled !== undefined ? config.whatsAppCheckEnabled : true);
        setUseWhatsAppSimulation(config.useWhatsAppSimulation !== undefined ? config.useWhatsAppSimulation : true);
        setWhatsAppApiUrl(config.whatsAppApiUrl || "");
        setWhatsAppApiKey(config.whatsAppApiKey || "");
        setWhatsAppInstanceName(config.whatsAppInstanceName || "validator-pro");
        setWhatsAppDelayMin(config.whatsAppDelayMin !== undefined ? config.whatsAppDelayMin : 2);
        setWhatsAppDelayMax(config.whatsAppDelayMax !== undefined ? config.whatsAppDelayMax : 6);
        setMaxChecksPerHour(config.maxChecksPerHour !== undefined ? config.maxChecksPerHour : 300);
      }
    } catch (err) {
      console.error("Failed to fetch WhatsApp config:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!token) return;
    setSaving(true);
    setStatusMsg(null);
    try {
      const res = await fetch("/api/validation/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          whatsAppCheckEnabled,
          useWhatsAppSimulation,
          whatsAppApiUrl,
          whatsAppApiKey,
          whatsAppInstanceName,
          whatsAppDelayMin: Number(whatsAppDelayMin),
          whatsAppDelayMax: Number(whatsAppDelayMax),
          maxChecksPerHour: Number(maxChecksPerHour),
        }),
      });

      if (res.ok) {
        setStatusMsg({ type: "success", text: "WhatsApp validation settings successfully updated." });
        setTimeout(() => {
          setStatusMsg(null);
        }, 1800);
      } else {
        const data = await res.json();
        setStatusMsg({ type: "error", text: data.error || "Failed to save configuration." });
      }
    } catch (err) {
      console.error("Failed to save rules:", err);
      setStatusMsg({ type: "error", text: "Network error. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  const handleGenerateQR = () => {
    setQrStatus("generating");
    setQrCodeData(null);
    
    setTimeout(() => {
      // Create a simulated beautiful QR payload
      setQrCodeData("https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=validator-pro-whatsapp-handshake-" + Math.floor(Math.random() * 99999));
      setQrStatus("waiting");
      setInstanceStatus("Pairing Instance...");

      // Simulate a user scanning and pairing after 5 seconds
      setTimeout(() => {
        setQrStatus("connecting");
        setInstanceStatus("Verifying session token...");
        
        setTimeout(() => {
          setQrStatus("connected");
          setInstanceStatus("Connected & Active");
        }, 2000);
      }, 5000);
    }, 1500);
  };

  if (!isOpen) return null;

  const isEditable = userRole === "Admin" || userRole === "Uploader";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-emerald-600 animate-pulse" />
            <h3 className="font-bold text-slate-900 text-sm">WhatsApp Verification Engine</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded-full hover:bg-slate-200 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {statusMsg && (
            <div className={`p-4 rounded-xl border flex items-start gap-3 text-xs leading-relaxed ${
              statusMsg.type === "success" 
                ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
                : "bg-red-50 border-red-200 text-red-800"
            }`}>
              {statusMsg.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              )}
              <span>{statusMsg.text}</span>
            </div>
          )}

          {!isEditable && (
            <div className="bg-amber-50 border border-amber-100 p-3.5 rounded-xl flex gap-3 text-xs text-amber-800">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p>
                <strong>View-Only Mode:</strong> Only <strong>Admins</strong> and <strong>Uploaders</strong> can modify WhatsApp gateways.
              </p>
            </div>
          )}

          {loading ? (
            <div className="py-12 text-center text-slate-400 font-mono text-xs">Loading gateway configuration...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Left Column: API & Mode Settings */}
              <div className="md:col-span-7 space-y-4">
                {/* 1. Toggle Checkbox */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-slate-900 text-xs block">Check WhatsApp Status</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">Verify number has registered WhatsApp account</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={whatsAppCheckEnabled}
                      disabled={!isEditable}
                      onChange={(e) => setWhatsAppCheckEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                {whatsAppCheckEnabled && (
                  <>
                    {/* 2. Execution Mode Selection */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-slate-700">Execution Environment</label>
                      <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
                        <button
                          type="button"
                          disabled={!isEditable}
                          onClick={() => setUseWhatsAppSimulation(true)}
                          className={`py-2 rounded-lg text-center text-xs font-semibold cursor-pointer transition ${
                            useWhatsAppSimulation
                              ? "bg-white text-slate-900 shadow-sm"
                              : "text-slate-500 hover:text-slate-700"
                          }`}
                        >
                          Simulation (Sandbox)
                        </button>
                        <button
                          type="button"
                          disabled={!isEditable}
                          onClick={() => setUseWhatsAppSimulation(false)}
                          className={`py-2 rounded-lg text-center text-xs font-semibold cursor-pointer transition ${
                            !useWhatsAppSimulation
                              ? "bg-white text-emerald-700 shadow-sm"
                              : "text-slate-500 hover:text-slate-700"
                          }`}
                        >
                          Evolution API (Prod)
                        </button>
                      </div>
                    </div>

                    {/* 3. API Config (Evolution API) */}
                    {!useWhatsAppSimulation && (
                      <div className="p-4 bg-emerald-50/40 border border-emerald-100 rounded-2xl space-y-3.5">
                        <div className="flex items-center gap-1.5 text-emerald-800 font-semibold text-xs pb-1 border-b border-emerald-100/50">
                          <Key className="w-4 h-4 text-emerald-600" />
                          <span>Evolution API Connection Details</span>
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono font-semibold text-slate-600 mb-1">API Base URL</label>
                          <input
                            type="text"
                            placeholder="https://api.yourdomain.com"
                            disabled={!isEditable}
                            value={whatsAppApiUrl}
                            onChange={(e) => setWhatsAppApiUrl(e.target.value)}
                            className="w-full text-xs font-mono px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono font-semibold text-slate-600 mb-1">API Security Token</label>
                          <input
                            type="password"
                            placeholder="Evolution Global API Token key"
                            disabled={!isEditable}
                            value={whatsAppApiKey}
                            onChange={(e) => setWhatsAppApiKey(e.target.value)}
                            className="w-full text-xs font-mono px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono font-semibold text-slate-600 mb-1">Instance Name</label>
                          <input
                            type="text"
                            placeholder="validator-pro"
                            disabled={!isEditable}
                            value={whatsAppInstanceName}
                            onChange={(e) => setWhatsAppInstanceName(e.target.value)}
                            className="w-full text-xs font-mono px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                          />
                        </div>
                      </div>
                    )}

                    {/* 4. Anti-Ban delay & rate limit sliders */}
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                      <div className="flex items-center gap-1.5 text-slate-800 font-semibold text-xs pb-1 border-b border-slate-200">
                        <Sliders className="w-4 h-4 text-blue-600" />
                        <span>Anti-Ban & Speed Controls</span>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-700">Random Delay Window</span>
                          <span className="font-mono text-blue-600 font-bold">{whatsAppDelayMin}s - {whatsAppDelayMax}s</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <span className="text-[10px] text-slate-400 block font-mono">Min Delay:</span>
                            <input
                              type="range"
                              min="0"
                              max="5"
                              step="1"
                              disabled={!isEditable}
                              value={whatsAppDelayMin}
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                setWhatsAppDelayMin(val);
                                if (val > whatsAppDelayMax) setWhatsAppDelayMax(val);
                              }}
                              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                            />
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block font-mono">Max Delay:</span>
                            <input
                              type="range"
                              min="2"
                              max="15"
                              step="1"
                              disabled={!isEditable}
                              value={whatsAppDelayMax}
                              onChange={(e) => setWhatsAppDelayMax(Math.max(Number(e.target.value), whatsAppDelayMin))}
                              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                            />
                          </div>
                        </div>
                        <p className="text-[10px] text-slate-400 italic">
                          A random delay of {whatsAppDelayMin}-{whatsAppDelayMax}s is introduced between each number check to simulate human behavior.
                        </p>
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <label className="font-semibold text-slate-700">Max Checks Per Hour</label>
                          <span className="font-mono text-blue-600 font-bold">{maxChecksPerHour} numbers</span>
                        </div>
                        <input
                          type="number"
                          min="10"
                          max="2000"
                          disabled={!isEditable}
                          value={maxChecksPerHour}
                          onChange={(e) => setMaxChecksPerHour(Number(e.target.value))}
                          className="w-full text-xs font-mono px-3 py-2 border border-slate-200 rounded-lg outline-none"
                        />
                        <p className="text-[10px] text-slate-400 italic">
                          Engine auto-pauses when reaching this threshold within 60 minutes to protect the WhatsApp account.
                        </p>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Right Column: QR Login Panel & Status */}
              <div className="md:col-span-5 flex flex-col justify-between border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 text-slate-800 font-semibold text-xs pb-1 border-b border-slate-200">
                    <QrCode className="w-4 h-4 text-blue-600" />
                    <span>WhatsApp QR Login Gateway</span>
                  </div>

                  {whatsAppCheckEnabled ? (
                    <div className="space-y-4 text-center">
                      {/* Connection status badge */}
                      <div className="flex items-center justify-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${
                          qrStatus === "connected" ? "bg-emerald-500" : "bg-amber-400"
                        }`}></span>
                        <span className="text-xs font-semibold text-slate-700">
                          Status: <span className={qrStatus === "connected" ? "text-emerald-600 font-bold" : "text-amber-600"}>{instanceStatus}</span>
                        </span>
                      </div>

                      {/* QR Box */}
                      <div className="bg-white border border-slate-200 rounded-xl p-4 w-48 h-48 mx-auto flex flex-col items-center justify-center shadow-sm relative overflow-hidden">
                        {qrStatus === "idle" && (
                          <div className="text-center text-slate-400 font-mono text-[11px] p-2 flex flex-col items-center justify-center gap-2">
                            <Smartphone className="w-10 h-10 text-slate-300" />
                            <span>Pair WhatsApp to begin live verification</span>
                          </div>
                        )}

                        {qrStatus === "generating" && (
                          <div className="flex flex-col items-center justify-center gap-2 text-slate-500 font-mono text-[10px]">
                            <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
                            <span>Creating Secure Instance...</span>
                          </div>
                        )}

                        {(qrStatus === "waiting" || qrStatus === "connecting") && qrCodeData && (
                          <div className="relative">
                            <img src={qrCodeData} alt="WhatsApp QR Code" className="w-40 h-40 object-contain" referrerPolicy="no-referrer" />
                            {qrStatus === "connecting" && (
                              <div className="absolute inset-0 bg-white/95 flex flex-col items-center justify-center gap-2 text-[10px] font-mono text-blue-600">
                                <RefreshCw className="w-6 h-6 animate-spin text-blue-500" />
                                <span>Establishing session...</span>
                              </div>
                            )}
                          </div>
                        )}

                        {qrStatus === "connected" && (
                          <div className="flex flex-col items-center justify-center gap-2 text-center">
                            <CheckCircle2 className="w-12 h-12 text-emerald-600 animate-bounce" />
                            <span className="text-xs font-bold text-emerald-800">Linked Successfully</span>
                            <span className="text-[9px] text-slate-400 font-mono">Instance ID: {whatsAppInstanceName}</span>
                          </div>
                        )}
                      </div>

                      {/* Info lines */}
                      <p className="text-[10px] text-slate-500 leading-relaxed font-mono px-2">
                        {qrStatus === "waiting" ? (
                          <span className="text-amber-600 font-bold animate-pulse">⚠️ Scan this QR with Linked Devices in your WhatsApp mobile app within 3 minutes.</span>
                        ) : qrStatus === "connected" ? (
                          <span className="text-emerald-700">Session active. Real-time number checks and profile pictures are active.</span>
                        ) : (
                          <span>Generate a connection session to link your phone.</span>
                        )}
                      </p>

                      {/* Action trigger */}
                      {isEditable && (
                        <button
                          onClick={handleGenerateQR}
                          disabled={qrStatus === "generating" || qrStatus === "connecting" || qrStatus === "connected"}
                          className="w-full flex items-center justify-center gap-2 py-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white font-semibold rounded-xl text-xs transition cursor-pointer shadow-sm disabled:opacity-50"
                        >
                          <Play className="w-3.5 h-3.5 fill-white" />
                          <span>Generate Connection QR</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-400 font-mono text-xs">
                      Enable WhatsApp Checks to link your account.
                    </div>
                  )}
                </div>

                <div className="bg-amber-50/50 border border-amber-100 p-2.5 rounded-xl text-[10px] text-slate-500 mt-4 leading-relaxed font-mono">
                  <p className="font-bold text-amber-800">Anti-Ban Pro Tips:</p>
                  <ul className="list-disc pl-3 mt-1 space-y-0.5">
                    <li>Use a seasoned account, not a fresh SIM</li>
                    <li>Ensure delays are at least 3-6 seconds</li>
                    <li>Limit batch runs to under 500 checks daily</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs transition cursor-pointer"
          >
            Cancel
          </button>
          {isEditable && (
            <button
              onClick={handleSave}
              disabled={saving || loading}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold rounded-lg text-xs shadow-sm transition cursor-pointer disabled:opacity-50"
            >
              {saving ? "Saving Changes..." : "Save Config"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
