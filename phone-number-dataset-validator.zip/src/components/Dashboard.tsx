import React from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import {
  Plus,
  Trash2,
  Play,
  Pause,
  AlertTriangle,
  Globe,
  Database,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Search,
  Sparkles,
  Smartphone,
  User,
  MessageSquare,
  MapPin,
  ShieldAlert,
} from "lucide-react";
import { DashboardStats, Session, UserRole } from "../types.ts";

interface DashboardProps {
  stats: DashboardStats;
  sessions: Session[];
  userRole: UserRole;
  onOpenSession: (sessionId: number) => void;
  onDeleteSession: (sessionId: number) => void;
  onTriggerAction: (sessionId: number, action: "start" | "pause" | "cancel") => void;
  onNavigateToUpload: () => void;
}

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#64748b"];

export default function Dashboard({
  stats,
  sessions,
  userRole,
  onOpenSession,
  onDeleteSession,
  onTriggerAction,
  onNavigateToUpload,
}: DashboardProps) {
  // Sandbox Quick Tester States
  const [sandboxNumber, setSandboxNumber] = React.useState("");
  const [sandboxResult, setSandboxResult] = React.useState<any>(null);
  const [sandboxLoading, setSandboxLoading] = React.useState(false);
  const [sandboxStep, setSandboxStep] = React.useState(0);

  // Blacklist Management States
  const [blacklist, setBlacklist] = React.useState<string[]>([]);
  const [newBlacklistNum, setNewBlacklistNum] = React.useState("");

  React.useEffect(() => {
    // Load config to get blacklist
    const loadConfig = async () => {
      try {
        const token = localStorage.getItem("auth_token") || "";
        const res = await fetch("/api/validation/config", {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.blacklistNumbers) {
            setBlacklist(data.blacklistNumbers);
          }
        }
      } catch (err) {
        console.error("Error loading blacklist config:", err);
      }
    };
    loadConfig();
  }, []);

  const handleSandboxScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sandboxNumber.trim()) return;

    setSandboxLoading(true);
    setSandboxResult(null);
    setSandboxStep(1);

    // Staggered step animation for premium visual feedback
    const timer1 = setTimeout(() => setSandboxStep(2), 400);
    const timer2 = setTimeout(() => setSandboxStep(3), 800);
    const timer3 = setTimeout(() => setSandboxStep(4), 1200);

    try {
      const token = localStorage.getItem("auth_token") || "";
      const res = await fetch("/api/validation/single", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ rawNumber: sandboxNumber })
      });

      const data = await res.json();
      
      setTimeout(() => {
        if (res.ok) {
          setSandboxResult(data);
        } else {
          setSandboxResult({ isValid: false, error: data.error || "Failed to scan." });
        }
        setSandboxLoading(false);
        setSandboxStep(5);
      }, 1600);

    } catch (err: any) {
      setTimeout(() => {
        setSandboxResult({ isValid: false, error: err?.message || "Scan failed." });
        setSandboxLoading(false);
        setSandboxStep(5);
      }, 1600);
    }
  };

  const handleAddBlacklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBlacklistNum.trim()) return;
    
    // Auto format minor check
    let formatted = newBlacklistNum.trim();
    if (!formatted.startsWith("+")) {
      formatted = "+" + formatted;
    }

    if (blacklist.includes(formatted)) {
      setNewBlacklistNum("");
      return;
    }

    const updated = [...blacklist, formatted];
    setBlacklist(updated);
    setNewBlacklistNum("");

    try {
      const token = localStorage.getItem("auth_token") || "";
      await fetch("/api/validation/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ blacklistNumbers: updated })
      });
    } catch (err) {
      console.error("Error updating blacklist:", err);
    }
  };

  const handleRemoveBlacklist = async (numToRemove: string) => {
    const updated = blacklist.filter(n => n !== numToRemove);
    setBlacklist(updated);

    try {
      const token = localStorage.getItem("auth_token") || "";
      await fetch("/api/validation/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ blacklistNumbers: updated })
      });
    } catch (err) {
      console.error("Error removing from blacklist:", err);
    }
  };

  // Percentages helpers
  const validRate = stats.totalNumbersValidated
    ? ((stats.totalValid / stats.totalNumbersValidated) * 100).toFixed(1)
    : "0.0";
  const invalidRate = stats.totalNumbersValidated
    ? ((stats.totalInvalid / stats.totalNumbersValidated) * 100).toFixed(1)
    : "0.0";

  return (
    <div id="dashboard_view" className="space-y-6">
      {/* Welcome / Actions Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Validation Dashboard</h2>
          <p className="text-slate-500 text-xs mt-1">
            Real-time status of phone number validations and country formatting.
          </p>
        </div>
        {userRole !== "Viewer" && (
          <button
            onClick={onNavigateToUpload}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold px-4 py-2.5 rounded-lg text-xs transition duration-150 shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Import New Dataset
          </button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Validated */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-slate-400 shadow-sm flex items-start gap-4">
          <div className="p-3 bg-slate-50 text-slate-500 rounded-lg border border-slate-200">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider block">Validated Numbers</span>
            <span className="text-2xl font-bold text-slate-900 font-mono mt-1 block">
              {stats.totalNumbersValidated.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-500 font-mono mt-1 block">
              across {stats.totalSessions} sessions
            </span>
          </div>
        </div>

        {/* Valid Numbers */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-green-500 shadow-sm flex items-start gap-4">
          <div className="p-3 bg-green-50 text-green-600 rounded-lg border border-green-100">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider block">Valid Numbers</span>
            <span className="text-2xl font-bold text-slate-900 font-mono mt-1 block">
              {stats.totalValid.toLocaleString()}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] text-green-700 font-bold bg-green-50 px-2 py-0.5 rounded-full mt-1.5 border border-green-100">
              {validRate}% success rate
            </span>
          </div>
        </div>

        {/* Invalid Numbers */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-red-500 shadow-sm flex items-start gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-lg border border-red-100">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider block">Invalid Numbers</span>
            <span className="text-2xl font-bold text-slate-900 font-mono mt-1 block">
              {stats.totalInvalid.toLocaleString()}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] text-red-700 font-bold bg-red-50 px-2 py-0.5 rounded-full mt-1.5 border border-red-100">
              {invalidRate}% failure rate
            </span>
          </div>
        </div>

        {/* Duplicates Cleaned */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-amber-500 shadow-sm flex items-start gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg border border-amber-100">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider block">Duplicates Removed</span>
            <span className="text-2xl font-bold text-slate-900 font-mono mt-1 block">
              {stats.totalDuplicatesCount.toLocaleString()}
            </span>
            <span className="text-[10px] text-amber-700 font-mono mt-1 block">
              deduplicated on import
            </span>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Trend Area Chart */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-500" />
              Validation Activity Trends
            </h3>
            <span className="text-[10px] text-slate-500 font-mono uppercase bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
              Monthly Growth
            </span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.monthlyTrends}>
                <defs>
                  <linearGradient id="colorValid" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorInvalid" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.6} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#ffffff", borderColor: "#e2e8f0", borderRadius: "8px", boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)" }}
                  labelStyle={{ color: "#0f172a", fontWeight: "bold", fontSize: 12 }}
                  itemStyle={{ fontSize: 12 }}
                />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Area
                  type="monotone"
                  dataKey="valid"
                  name="Valid Numbers"
                  stroke="#10b981"
                  fillOpacity={1}
                  fill="url(#colorValid)"
                />
                <Area
                  type="monotone"
                  dataKey="invalid"
                  name="Invalid Numbers"
                  stroke="#ef4444"
                  fillOpacity={1}
                  fill="url(#colorInvalid)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Geographical Bar Chart */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-500" />
              Country Distribution (Valid)
            </h3>
            <span className="text-[10px] text-slate-500 font-mono uppercase bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
              E.164 Prefix
            </span>
          </div>
          <div className="h-64">
            {stats.countryDistribution.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 border border-dashed border-slate-200 rounded-xl">
                <Globe className="w-8 h-8 text-slate-400 mb-2" />
                <p className="text-slate-500 text-xs">No validated E.164 country records found.</p>
                <p className="text-[10px] text-slate-400 mt-1">Validate numbers to see mapping.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.countryDistribution} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.6} horizontal={false} />
                  <XAxis type="number" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis dataKey="country" type="category" stroke="#94a3b8" fontSize={11} tickLine={false} width={60} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#ffffff", borderColor: "#e2e8f0", borderRadius: "8px", boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)" }}
                    itemStyle={{ fontSize: 12, color: "#1e293b" }}
                  />
                  <Bar dataKey="count" name="Valid Count" radius={[0, 4, 4, 0]}>
                    {stats.countryDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Bento: Sandbox Tester & Blacklist Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sandbox Quick Scan */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 tracking-tight">Single Number Quick Scan Sandbox</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Ad-hoc real-time telephone verification &amp; simulated live WhatsApp handshake checks.
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSandboxScan} className="mt-4 flex gap-2">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Enter number (e.g. +14155552671)"
                  value={sandboxNumber}
                  onChange={(e) => setSandboxNumber(e.target.value)}
                  className="w-full bg-slate-50 hover:bg-slate-100/50 text-slate-800 text-xs border border-slate-200 rounded-lg pl-9 pr-3.5 py-2.5 focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none font-mono shadow-inner"
                />
              </div>
              <button
                type="submit"
                disabled={sandboxLoading || !sandboxNumber.trim()}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition shadow-sm cursor-pointer whitespace-nowrap shrink-0"
              >
                {sandboxLoading ? "Scanning..." : "Quick Scan"}
              </button>
            </form>

            {/* Scanning Status Steps */}
            {sandboxLoading && (
              <div className="mt-4 bg-slate-50 border border-slate-100 rounded-lg p-3.5 space-y-2.5 font-mono text-[11px] text-slate-500">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${sandboxStep >= 1 ? "bg-green-500 animate-ping" : "bg-slate-300"}`} />
                  <span>Formatting & normalization: <strong className="text-slate-700">{sandboxNumber}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${sandboxStep >= 2 ? "bg-green-500 animate-ping" : "bg-slate-300"}`} />
                  <span>Checking Global DNC / Blacklist database...</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${sandboxStep >= 3 ? "bg-green-500 animate-ping" : "bg-slate-300"}`} />
                  <span>Executing carrier structure validation rules...</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${sandboxStep >= 4 ? "bg-indigo-500 animate-ping" : "bg-slate-300"}`} />
                  <span>Initiating live WhatsApp network gateway handshake query...</span>
                </div>
              </div>
            )}

            {/* Scan results render */}
            {sandboxResult && !sandboxLoading && (
              <div className="mt-4 border border-slate-100 rounded-xl overflow-hidden shadow-sm animate-fade-in bg-slate-50">
                <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Scan Summary Report</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    sandboxResult.isValid 
                      ? "bg-green-50 text-green-700 border border-green-200" 
                      : "bg-red-50 text-red-700 border border-red-200"
                  }`}>
                    {sandboxResult.isValid ? "Valid Structure" : "Invalid Number"}
                  </span>
                </div>

                <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Left stats columns */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2.5">
                      <Smartphone className="w-4 h-4 text-slate-400 shrink-0" />
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-semibold">Formatted</span>
                        <span className="text-xs font-bold text-slate-800 font-mono">{sandboxResult.formattedNumber || "N/A"}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <Globe className="w-4 h-4 text-slate-400 shrink-0" />
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-semibold">Region / Code</span>
                        <span className="text-xs font-bold text-slate-800 font-mono">
                          {sandboxResult.countryCode || "Unknown"} (Prefix: {sandboxResult.prefix || "N/A"})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-semibold">Line Type &amp; Timezone</span>
                        <span className="text-xs font-bold text-slate-800 font-sans">
                          {sandboxResult.lineType || "N/A"} • {sandboxResult.timezone || "N/A"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right WhatsApp specific details */}
                  <div className="border-t md:border-t-0 md:border-l border-slate-200/60 pt-3 md:pt-0 md:pl-4">
                    {sandboxResult.whatsApp?.hasWhatsApp ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 bg-emerald-50/70 border border-emerald-100 rounded-lg p-2">
                          <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 animate-pulse" />
                          <span className="text-[10px] font-bold text-emerald-800 uppercase font-sans">WhatsApp account active</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <img
                            src={sandboxResult.whatsApp.waProfilePic || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80"}
                            alt="Avatar"
                            className="w-10 h-10 rounded-full object-cover border border-slate-200"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-slate-800 leading-tight block">
                                {sandboxResult.whatsApp.waProfileName || "N/A"}
                              </span>
                              {sandboxResult.whatsApp.waIsBusiness && (
                                <span className="bg-blue-50 text-blue-600 text-[9px] font-bold px-1 py-0.2 rounded border border-blue-100">
                                  Business
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono italic block line-clamp-1">
                              "{sandboxResult.whatsApp.waAboutText || "Hello!"}"
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2 py-3 flex flex-col items-center justify-center text-center">
                        <MessageSquare className="w-8 h-8 text-slate-300" />
                        <p className="text-[11px] font-semibold text-slate-500">
                          No Active WhatsApp Presence Detected
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {!sandboxResult.isValid && (
                  <div className="px-4 py-2.5 bg-red-50 border-t border-red-100 text-red-600 text-[11px] font-medium flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                    <span>Error: {sandboxResult.validationError || "Unrecognized digits formatting for this country plan"}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Global Blacklist registry */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 tracking-tight">Global DNC &amp; Blacklist Registry</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Avoid critical carrier blocks. Numbers blacklisted here will automatically fail validation.
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleAddBlacklist} className="mt-4 flex gap-2">
              <input
                type="text"
                placeholder="Add to blacklist (e.g. +155512345)"
                value={newBlacklistNum}
                onChange={(e) => setNewBlacklistNum(e.target.value)}
                className="flex-grow bg-slate-50 hover:bg-slate-100/50 text-slate-800 text-xs border border-slate-200 rounded-lg px-3.5 py-2.5 focus:bg-white focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none font-mono shadow-inner"
              />
              <button
                type="submit"
                disabled={!newBlacklistNum.trim()}
                className="bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition shadow-sm cursor-pointer shrink-0"
              >
                Blacklist
              </button>
            </form>

            <div className="mt-4 space-y-1.5">
              <span className="text-[10px] text-slate-400 block uppercase font-semibold">
                DNC Numbers Registry ({blacklist.length})
              </span>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 max-h-[170px] overflow-y-auto divide-y divide-slate-100 font-mono text-xs text-slate-700 shadow-inner">
                {blacklist.length === 0 ? (
                  <div className="text-center py-6 text-slate-400 text-[11px] font-sans">
                    No numbers registered in global blacklist yet.
                  </div>
                ) : (
                  blacklist.map((num, idx) => (
                    <div key={idx} className="py-2 flex items-center justify-between">
                      <span className="font-semibold text-slate-700">{num}</span>
                      <button
                        onClick={() => handleRemoveBlacklist(num)}
                        className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition cursor-pointer"
                        title="Remove from Blacklist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sessions List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
        <div className="px-6 py-5 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
              Validation Datasets ({sessions.length})
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Datasets uploaded and verified. Click a dataset to view detailed phone records.
            </p>
          </div>
        </div>

        {sessions.length === 0 ? (
          <div className="p-12 text-center bg-white">
            <Database className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <p className="text-slate-800 font-bold">No Phone Number Datasets Yet</p>
            <p className="text-slate-500 text-xs mt-1 max-w-sm mx-auto">
              Ready to standardise your lists? Import a text or CSV file with up to 10,000 phone numbers.
            </p>
            {userRole !== "Viewer" && (
              <button
                onClick={onNavigateToUpload}
                className="mt-4 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg text-xs transition duration-150 cursor-pointer shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Upload First Dataset
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-xs font-mono bg-slate-50">
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider">Dataset Name</th>
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider">Status</th>
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider">Total Size</th>
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider">Progress Bar</th>
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider">Diagnostics</th>
                  <th className="py-4 px-6 font-semibold uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600 text-xs bg-white">
                {sessions.map((session) => {
                  const percent = session.totalCount
                    ? Math.round((session.processedCount / session.totalCount) * 100)
                    : 0;

                  // Status Badge Classes
                  let statusBg = "bg-slate-100 border-slate-200 text-slate-600";
                  if (session.status === "Processing") statusBg = "bg-blue-50 border-blue-200 text-blue-600 animate-pulse";
                  else if (session.status === "Paused") statusBg = "bg-amber-50 border-amber-200 text-amber-700";
                  else if (session.status === "Completed") statusBg = "bg-green-50 border-green-200 text-green-700";
                  else if (session.status === "Cancelled") statusBg = "bg-red-50 border-red-200 text-red-700";

                  return (
                    <tr key={session.id} className="hover:bg-blue-50/40 transition duration-150 group">
                      <td className="py-4 px-6 font-bold text-slate-800 group-hover:text-blue-600">
                        <button
                          onClick={() => onOpenSession(session.id)}
                          className="flex items-center gap-1.5 hover:underline text-left cursor-pointer font-sans"
                        >
                          {session.name}
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </button>
                        <span className="block text-[10px] text-slate-400 font-mono mt-0.5">
                          Created {new Date(session.createdAt).toLocaleDateString()} {new Date(session.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-bold font-mono ${statusBg}`}>
                          {session.status}
                        </span>
                      </td>
                      <td className="py-4 px-6 font-mono text-slate-500">
                        {session.totalCount.toLocaleString()} numbers
                      </td>
                      <td className="py-4 px-6 max-w-xs">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-100 h-2.5 rounded-full overflow-hidden">
                            <div
                              className={`h-full transition-all duration-300 ${
                                session.status === "Completed"
                                  ? "bg-green-500"
                                  : session.status === "Cancelled"
                                  ? "bg-red-500"
                                  : session.status === "Paused"
                                  ? "bg-amber-500"
                                  : "bg-blue-600"
                              }`}
                              style={{ width: `${percent}%` }}
                            ></div>
                          </div>
                          <span className="font-mono text-xs text-slate-500 min-w-10">
                            {percent}%
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1 font-mono flex gap-2">
                          <span className="text-green-600 font-semibold">{session.validCount} valid</span>
                          <span className="text-slate-300">|</span>
                          <span className="text-red-500 font-semibold">{session.invalidCount} invalid</span>
                          {session.duplicateCount > 0 && (
                            <>
                              <span className="text-slate-300">|</span>
                              <span className="text-amber-600 font-semibold">{session.duplicateCount} dup</span>
                            </>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-[10px] text-slate-400 font-mono block">
                          Processed: {session.processedCount} / {session.totalCount}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {userRole !== "Viewer" && session.status !== "Completed" && session.status !== "Cancelled" && (
                            <>
                              {session.status === "Processing" ? (
                                <button
                                  onClick={() => onTriggerAction(session.id, "pause")}
                                  title="Pause processing"
                                  className="p-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-600 rounded-lg transition duration-150 cursor-pointer"
                                >
                                  <Pause className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <button
                                  onClick={() => onTriggerAction(session.id, "start")}
                                  title="Start processing"
                                  className="p-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-600 rounded-lg transition duration-150 cursor-pointer"
                                >
                                  <Play className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </>
                          )}

                          <button
                            onClick={() => onOpenSession(session.id)}
                            className="bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-2.5 py-1.5 rounded-lg text-xs transition duration-150 cursor-pointer shadow-sm"
                          >
                            Details
                          </button>

                          {userRole !== "Viewer" && (
                            <button
                              onClick={() => onDeleteSession(session.id)}
                              title="Delete dataset"
                              className="p-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 rounded-lg transition duration-150 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
