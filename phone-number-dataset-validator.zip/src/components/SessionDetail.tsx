import React, { useState, useEffect, useCallback } from "react";
import {
  Play,
  Pause,
  ArrowLeft,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Download,
  AlertTriangle,
  RotateCw,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Edit,
} from "lucide-react";
import { Session, PhoneNumber, ProcessingLog, UserRole } from "../types.ts";

interface SessionDetailProps {
  sessionId: number;
  userRole: UserRole;
  onBackToDashboard: () => void;
  onDeleteSession: (sessionId: number) => void;
}

export default function SessionDetail({
  sessionId,
  userRole,
  onBackToDashboard,
  onDeleteSession,
}: SessionDetailProps) {
  // Session details state
  const [session, setSession] = useState<Session | null>(null);
  const [logs, setLogs] = useState<ProcessingLog[]>([]);
  const [numbers, setNumbers] = useState<PhoneNumber[]>([]);
  
  // Table state (Pagination, Filter, Sort, Search)
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(50);
  const [totalPages, setTotalPages] = useState(1);
  const [totalNumbers, setTotalNumbers] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [countryFilter, setCountryFilter] = useState("all");
  const [whatsAppFilter, setWhatsAppFilter] = useState("all");
  const [lineTypeFilter, setLineTypeFilter] = useState("all");
  const [tagQuery, setTagQuery] = useState("");
  const [sortBy, setSortBy] = useState("id");
  const [sortOrder, setSortOrder] = useState("asc");

  // Selection states
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Metadata editing state
  const [editingNumber, setEditingNumber] = useState<PhoneNumber | null>(null);
  const [editNotes, setEditNotes] = useState("");
  const [editTags, setEditTags] = useState("");

  // Bulk actions state
  const [bulkAction, setBulkAction] = useState<"delete" | "tag" | "blacklist" | "">("");
  const [bulkTagValue, setBulkTagValue] = useState("");
  const [bulkProcessing, setBulkProcessing] = useState(false);
  
  // UI Loading states
  const [loadingMetadata, setLoadingMetadata] = useState(true);
  const [loadingNumbers, setLoadingNumbers] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [exportFilter, setExportFilter] = useState("all");

  const [authToken, setAuthToken] = useState<string>("");

  // Grab active auth token from local/session storage or global state
  useEffect(() => {
    const token = sessionStorage.getItem("auth_token") || "";
    setAuthToken(token);
  }, []);

  // Fetch session meta
  const fetchSessionMeta = useCallback(async () => {
    if (!authToken) return;
    try {
      const res = await fetch(`/api/sessions/${sessionId}`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSession(data);
      }
    } catch (err) {
      console.error("Failed to load session meta:", err);
    } finally {
      setLoadingMetadata(false);
    }
  }, [sessionId, authToken]);

  // Fetch logs
  const fetchSessionLogs = useCallback(async () => {
    if (!authToken) return;
    try {
      const res = await fetch(`/api/sessions/${sessionId}/logs`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (err) {
      console.error("Failed to load logs:", err);
    }
  }, [sessionId, authToken]);

  // Fetch paginated, sorted, filtered phone numbers
  const fetchSessionNumbers = useCallback(async () => {
    if (!authToken) return;
    setLoadingNumbers(true);
    try {
      const queryParams = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
        search: searchQuery,
        isValid: statusFilter,
        countryCode: countryFilter,
        whatsApp: whatsAppFilter,
        lineType: lineTypeFilter,
        tag: tagQuery,
        sortBy,
        sortOrder,
      });

      const res = await fetch(`/api/sessions/${sessionId}/numbers?${queryParams}`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });

      if (res.ok) {
        const data = await res.json();
        setNumbers(data.numbers);
        setTotalPages(data.totalPages);
        setTotalNumbers(data.total);
      }
    } catch (err) {
      console.error("Failed to load numbers:", err);
    } finally {
      setLoadingNumbers(false);
    }
  }, [
    sessionId,
    authToken,
    page,
    limit,
    searchQuery,
    statusFilter,
    countryFilter,
    whatsAppFilter,
    lineTypeFilter,
    tagQuery,
    sortBy,
    sortOrder,
  ]);

  // Initial loads
  useEffect(() => {
    if (authToken) {
      fetchSessionMeta();
      fetchSessionLogs();
      fetchSessionNumbers();
    }
  }, [authToken, fetchSessionMeta, fetchSessionLogs, fetchSessionNumbers]);

  // Real-time status polling when session is "Processing"
  useEffect(() => {
    let intervalId: any = null;

    if (session && session.status === "Processing") {
      intervalId = setInterval(() => {
        fetchSessionMeta();
        fetchSessionLogs();
        fetchSessionNumbers();
      }, 1500);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [session?.status, fetchSessionMeta, fetchSessionLogs, fetchSessionNumbers]);

  // Reset pagination on filter adjustments
  const handleFilterChange = (
    type: "status" | "country" | "search" | "whatsApp" | "lineType" | "tag",
    val: string
  ) => {
    setPage(1);
    setSelectedIds([]);
    if (type === "status") setStatusFilter(val);
    else if (type === "country") setCountryFilter(val);
    else if (type === "search") setSearchQuery(val);
    else if (type === "whatsApp") setWhatsAppFilter(val);
    else if (type === "lineType") setLineTypeFilter(val);
    else if (type === "tag") setTagQuery(val);
  };

  // Save inline notes/tags metadata
  const handleSaveMetadata = async () => {
    if (!editingNumber || !authToken) return;
    try {
      const res = await fetch(`/api/numbers/${editingNumber.id}/metadata`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ notes: editNotes, tags: editTags }),
      });
      if (res.ok) {
        setEditingNumber(null);
        fetchSessionNumbers();
        fetchSessionLogs();
      } else {
        const d = await res.json();
        setError(d.error || "Failed to save details");
      }
    } catch (err: any) {
      setError(err?.message || "Failed to update metadata");
    }
  };

  // Submit bulk action
  const handleExecuteBulkAction = async () => {
    if (!bulkAction || selectedIds.length === 0 || !authToken) return;
    setBulkProcessing(true);
    setError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/numbers/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          ids: selectedIds,
          action: bulkAction,
          tagValue: bulkAction === "tag" ? bulkTagValue : undefined,
        }),
      });

      if (res.ok) {
        setSelectedIds([]);
        setBulkAction("");
        setBulkTagValue("");
        fetchSessionNumbers();
        fetchSessionMeta();
        fetchSessionLogs();
      } else {
        const d = await res.json();
        setError(d.error || "Bulk action failed");
      }
    } catch (err: any) {
      setError(err?.message || "Error running bulk action");
    } finally {
      setBulkProcessing(false);
    }
  };

  // Sort toggler
  const handleSortChange = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("asc");
    }
    setPage(1);
  };

  // Control actions (start, pause, cancel)
  const handleTriggerAction = async (action: "start" | "pause" | "cancel") => {
    if (userRole === "Viewer") {
      setError("Permission Denied: Viewers cannot manage processing jobs.");
      return;
    }
    setActionLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/action`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ action }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to trigger action.");
      }

      const updatedSession = await res.json();
      setSession(updatedSession);
      fetchSessionLogs();
      fetchSessionNumbers();
    } catch (err: any) {
      setError(err?.message || "An error occurred.");
    } finally {
      setActionLoading(false);
    }
  };

  // Bulk Row Checkbox toggles
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      const currentPageIds = numbers.map((n) => n.id);
      setSelectedIds(currentPageIds);
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectRow = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  // Execute Bulk Actions
  const handleBulkAction = async (action: "delete" | "revalidate") => {
    if (userRole === "Viewer") {
      setError("Permission Denied: Viewers cannot make updates.");
      return;
    }
    if (selectedIds.length === 0) return;

    if (
      action === "delete" &&
      !window.confirm(`Are you sure you want to delete ${selectedIds.length} checked records?`)
    ) {
      return;
    }

    setActionLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/bulk-action`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ action, ids: selectedIds }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to execute bulk action.");
      }

      const updatedSession = await res.json();
      setSession(updatedSession);
      setSelectedIds([]);
      fetchSessionLogs();
      fetchSessionNumbers();
    } catch (err: any) {
      setError(err?.message || "An error occurred.");
    } finally {
      setActionLoading(false);
    }
  };

  // Download Logs File
  const handleDownloadLogs = () => {
    window.open(`/api/sessions/${sessionId}/logs-export?id=${sessionId}`, "_blank");
  };

  // Trigger file download helper
  const handleExportFile = (format: "csv" | "xls" | "txt") => {
    const query = new URLSearchParams({
      format,
      filter: exportFilter,
    });
    window.open(`/api/sessions/${sessionId}/export?${query}`, "_blank");
    setExportOpen(false);
  };

  if (loadingMetadata && !session) {
    return (
      <div className="flex items-center justify-center p-20 text-slate-500 gap-2 font-mono text-xs">
        <RotateCw className="w-4 h-4 animate-spin text-blue-500" />
        LOADING DATASET STATISTICS...
      </div>
    );
  }

  const percent = session
    ? session.totalCount
      ? Math.round((session.processedCount / session.totalCount) * 100)
      : 0
    : 0;

  // Status Badge Classes
  let statusBg = "bg-slate-100 border-slate-200 text-slate-600";
  if (session?.status === "Processing") statusBg = "bg-blue-50 border-blue-200 text-blue-600 animate-pulse";
  else if (session?.status === "Paused") statusBg = "bg-amber-50 border-amber-200 text-amber-700";
  else if (session?.status === "Completed") statusBg = "bg-green-50 border-green-200 text-green-700";
  else if (session?.status === "Cancelled") statusBg = "bg-red-50 border-red-200 text-red-700";

  return (
    <div id="session_detail_view" className="space-y-6 animate-fade-in">
      {/* Detail Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50 p-5 rounded-xl border border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDashboard}
            className="p-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-600 transition cursor-pointer shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">{session?.name}</h2>
              <span className={`px-2.5 py-0.5 rounded-full border text-[11px] font-mono font-bold ${statusBg}`}>
                {session?.status}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono mt-1">
              ID: {session?.id} &bull; Created {session ? new Date(session.createdAt).toLocaleDateString() : ""}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {userRole !== "Viewer" && (
            <>
              {session?.status === "Processing" ? (
                <button
                  onClick={() => handleTriggerAction("pause")}
                  disabled={actionLoading}
                  className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 font-bold px-3 py-1.5 rounded-lg text-xs transition duration-150 cursor-pointer disabled:opacity-50 shadow-sm"
                >
                  <Pause className="w-3.5 h-3.5" /> Pause Run
                </button>
              ) : (
                session?.status !== "Completed" && (
                  <button
                    onClick={() => handleTriggerAction("start")}
                    disabled={actionLoading}
                    className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition duration-150 cursor-pointer disabled:opacity-50 shadow-sm"
                  >
                    <Play className="w-3.5 h-3.5" /> Resume / Start Run
                  </button>
                )
              )}

              {session?.status === "Processing" || session?.status === "Paused" ? (
                <button
                  onClick={() => handleTriggerAction("cancel")}
                  disabled={actionLoading}
                  className="flex items-center gap-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 font-bold px-3 py-1.5 rounded-lg text-xs transition duration-150 cursor-pointer disabled:opacity-50"
                >
                  Cancel Run
                </button>
              ) : null}
            </>
          )}

          {/* Export Dropdown */}
          <div className="relative">
            <button
              onClick={() => setExportOpen(!exportOpen)}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs transition duration-150 cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5" /> Export Data
            </button>

            {exportOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-lg shadow-xl p-3 z-50 space-y-2 text-slate-700">
                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block border-b border-slate-100 pb-1 font-bold">
                  Select Filter Target
                </span>
                <div className="flex flex-col gap-1 text-xs">
                  <label className="flex items-center gap-1.5 p-1 rounded hover:bg-slate-50 cursor-pointer">
                    <input
                      type="radio"
                      name="exportFilter"
                      checked={exportFilter === "all"}
                      onChange={() => setExportFilter("all")}
                    />
                    Export All ({session?.totalCount})
                  </label>
                  <label className="flex items-center gap-1.5 p-1 rounded hover:bg-slate-50 cursor-pointer">
                    <input
                      type="radio"
                      name="exportFilter"
                      checked={exportFilter === "valid"}
                      onChange={() => setExportFilter("valid")}
                    />
                    Valid Only ({session?.validCount})
                  </label>
                  <label className="flex items-center gap-1.5 p-1 rounded hover:bg-slate-50 cursor-pointer">
                    <input
                      type="radio"
                      name="exportFilter"
                      checked={exportFilter === "invalid"}
                      onChange={() => setExportFilter("invalid")}
                    />
                    Invalid Only ({session?.invalidCount})
                  </label>
                </div>
                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block border-b border-slate-100 pb-1 pt-1 font-bold">
                  Download Formats
                </span>
                <div className="grid grid-cols-3 gap-1.5 text-xs pt-1">
                  <button
                    onClick={() => handleExportFile("csv")}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 rounded transition cursor-pointer text-center font-mono text-[10px] font-semibold border border-slate-200"
                  >
                    CSV
                  </button>
                  <button
                    onClick={() => handleExportFile("xls")}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 rounded transition cursor-pointer text-center font-mono text-[10px] font-semibold border border-slate-200"
                  >
                    Excel
                  </button>
                  <button
                    onClick={() => handleExportFile("txt")}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 rounded transition cursor-pointer text-center font-mono text-[10px] font-semibold border border-slate-200"
                  >
                    TXT
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2 leading-relaxed">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
          <span>{error}</span>
        </div>
      )}

      {/* Progress & Stat Panels */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <span className="text-xs font-bold text-slate-800 tracking-tight font-mono">
            Overall Processing Progress
          </span>
          <span className="text-xs font-mono text-slate-500">
            Validated {session?.processedCount.toLocaleString()} of {session?.totalCount.toLocaleString()} items
          </span>
        </div>

        {/* Progress Bar */}
        <div className="relative h-4.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
          <div
            className={`h-full transition-all duration-300 ${
              session?.status === "Completed"
                ? "bg-green-500"
                : session?.status === "Cancelled"
                ? "bg-red-500"
                : session?.status === "Paused"
                ? "bg-amber-500"
                : "bg-blue-600"
            }`}
            style={{ width: `${percent}%` }}
          ></div>
          <span className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold text-slate-700 drop-shadow-sm">
            {percent}% Completed
          </span>
        </div>

        {/* Validation Breakdowns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-center">
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Imported</span>
            <span className="text-lg font-bold text-slate-800 font-mono mt-0.5 block">{session?.totalCount}</span>
          </div>
          <div className="bg-green-50/40 p-3.5 rounded-xl border border-green-100 text-center">
            <span className="text-[10px] text-green-600 font-bold uppercase tracking-wider block">Valid (Success)</span>
            <span className="text-lg font-bold text-green-700 font-mono mt-0.5 block">{session?.validCount}</span>
          </div>
          <div className="bg-red-50/40 p-3.5 rounded-xl border border-red-100 text-center">
            <span className="text-[10px] text-red-500 font-bold uppercase tracking-wider block">Invalid (Failed)</span>
            <span className="text-lg font-bold text-red-600 font-mono mt-0.5 block">{session?.invalidCount}</span>
          </div>
          <div className="bg-amber-50/40 p-3.5 rounded-xl border border-amber-100 text-center">
            <span className="text-[10px] text-amber-500 font-bold uppercase tracking-wider block">Duplicates Skipped</span>
            <span className="text-lg font-bold text-amber-600 font-mono mt-0.5 block">{session?.duplicateCount}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Dataset Table & Real-time Logs */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Table Column */}
        <div className="xl:col-span-8 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden space-y-4 py-5">
          <div className="px-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Standardised Dataset</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Filtered: {totalNumbers} matching records
              </p>
            </div>

            {/* Filters bar */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {/* Search */}
              <div className="relative flex-grow md:flex-none">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search raw/notes/tags..."
                  value={searchQuery}
                  onChange={(e) => handleFilterChange("search", e.target.value)}
                  className="w-full md:w-36 bg-white border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 outline-none text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition font-sans shadow-sm"
                />
              </div>

              {/* Tag Query */}
              <input
                type="text"
                placeholder="Tag name..."
                value={tagQuery}
                onChange={(e) => handleFilterChange("tag", e.target.value)}
                className="w-full md:w-24 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 outline-none text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition font-sans shadow-sm"
              />

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => handleFilterChange("status", e.target.value)}
                className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 outline-none text-xs text-slate-700 focus:border-blue-500 cursor-pointer font-sans shadow-sm text-[11px]"
              >
                <option value="all">All Status</option>
                <option value="true">Valid</option>
                <option value="false">Invalid</option>
                <option value="null">Pending</option>
              </select>

              {/* WhatsApp Filter */}
              <select
                value={whatsAppFilter}
                onChange={(e) => handleFilterChange("whatsApp", e.target.value)}
                className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 outline-none text-xs text-slate-700 focus:border-blue-500 cursor-pointer font-sans shadow-sm text-[11px]"
              >
                <option value="all">All WhatsApp</option>
                <option value="yes">WA Active</option>
                <option value="no">No WA</option>
                <option value="unchecked">Unchecked</option>
              </select>

              {/* Line Type Filter */}
              <select
                value={lineTypeFilter}
                onChange={(e) => handleFilterChange("lineType", e.target.value)}
                className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 outline-none text-xs text-slate-700 focus:border-blue-500 cursor-pointer font-sans shadow-sm text-[11px]"
              >
                <option value="all">All Lines</option>
                <option value="Mobile">Mobile</option>
                <option value="Landline">Landline</option>
                <option value="VOIP">VOIP</option>
              </select>

              {/* Country Filter */}
              <select
                value={countryFilter}
                onChange={(e) => handleFilterChange("country", e.target.value)}
                className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 outline-none text-xs text-slate-700 focus:border-blue-500 cursor-pointer font-sans shadow-sm text-[11px]"
              >
                <option value="all">All Countries</option>
                <option value="US/CA">US/CA (+1)</option>
                <option value="UK">UK (+44)</option>
                <option value="DE">Germany (+49)</option>
                <option value="FR">France (+33)</option>
                <option value="IN">India (+91)</option>
                <option value="AU">Australia (+61)</option>
                <option value="BR">Brazil (+55)</option>
                <option value="AE">UAE (+971)</option>
                <option value="Unknown">Unknown Code</option>
              </select>
            </div>
          </div>

          {/* Bulk Selection Actions Panel */}
          {selectedIds.length > 0 && userRole !== "Viewer" && (
            <div className="mx-6 px-5 py-3.5 bg-indigo-50/75 border border-indigo-100 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs animate-fade-in text-indigo-950 shadow-sm">
              <div className="flex items-center gap-2 font-semibold">
                <span className="p-1 bg-indigo-100 text-indigo-700 rounded text-[10px] font-mono">
                  {selectedIds.length} checked
                </span>
                <span>Select a bulk operation to run on this batch:</span>
              </div>
              <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                {/* Tag Input */}
                <div className="flex items-center bg-white border border-indigo-100 rounded-lg overflow-hidden pl-2">
                  <input
                    type="text"
                    placeholder="Enter tag value..."
                    value={bulkTagValue}
                    onChange={(e) => setBulkTagValue(e.target.value)}
                    className="w-28 bg-transparent border-none outline-none py-1 text-slate-800 text-[11px]"
                  />
                  <button
                    onClick={() => {
                      setBulkAction("tag");
                      setTimeout(() => handleExecuteBulkAction(), 50);
                    }}
                    disabled={bulkProcessing || !bulkTagValue.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-2.5 py-1.5 text-[10px] transition disabled:opacity-40 cursor-pointer"
                  >
                    Apply Tag
                  </button>
                </div>

                {/* Blacklist */}
                <button
                  onClick={() => {
                    if (window.confirm(`Add these ${selectedIds.length} numbers to the Global Blacklist & DNC Registry?`)) {
                      setBulkAction("blacklist");
                      setTimeout(() => handleExecuteBulkAction(), 50);
                    }
                  }}
                  disabled={bulkProcessing}
                  className="flex items-center gap-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold px-3 py-1.5 rounded-lg text-[11px] transition shadow-xs cursor-pointer"
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-500" /> DNC Blacklist
                </button>

                {/* Legacy Re-validate */}
                <button
                  onClick={() => handleBulkAction("revalidate")}
                  disabled={actionLoading || bulkProcessing}
                  className="flex items-center gap-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-3 py-1.5 rounded-lg text-[11px] transition cursor-pointer"
                >
                  <RotateCw className="w-3 h-3 text-slate-500" /> Re-Validate
                </button>

                {/* Delete */}
                <button
                  onClick={() => {
                    if (window.confirm(`Permanently delete ${selectedIds.length} checked records from this session?`)) {
                      setBulkAction("delete");
                      setTimeout(() => handleExecuteBulkAction(), 50);
                    }
                  }}
                  disabled={bulkProcessing}
                  className="flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded-lg text-[11px] transition cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" /> Delete Rows
                </button>
              </div>
            </div>
          )}

          {/* Phone Numbers Dataset Table */}
          <div className="overflow-x-auto min-h-[300px]">
            {loadingNumbers && numbers.length === 0 ? (
              <div className="py-20 text-center text-slate-500 font-mono text-xs flex justify-center items-center gap-2">
                <RotateCw className="w-4 h-4 animate-spin text-blue-500" />
                LOADING NUMBERS...
              </div>
            ) : numbers.length === 0 ? (
              <div className="py-20 text-center border-t border-slate-200">
                <Search className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-slate-500 text-xs">No records matching your active filters.</p>
              </div>
            ) : (
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-xs font-mono bg-slate-50">
                    {userRole !== "Viewer" && (
                      <th className="py-3 px-4 w-10">
                        <input
                          type="checkbox"
                          checked={selectedIds.length === numbers.length && numbers.length > 0}
                          onChange={handleSelectAll}
                          className="rounded text-blue-600 border-slate-300 focus:ring-blue-500 focus:ring-offset-0 cursor-pointer"
                        />
                      </th>
                    )}
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("rawNumber")}
                    >
                      Raw Input {sortBy === "rawNumber" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("formattedNumber")}
                    >
                      Formatted {sortBy === "formattedNumber" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("hasWhatsApp")}
                    >
                      WhatsApp {sortBy === "hasWhatsApp" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("isValid")}
                    >
                      Status {sortBy === "isValid" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("validationError")}
                    >
                      Failure Reason {sortBy === "validationError" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900 uppercase tracking-wider text-[11px]"
                      onClick={() => handleSortChange("countryCode")}
                    >
                      ISO {sortBy === "countryCode" && (sortOrder === "asc" ? "▲" : "▼")}
                    </th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">
                      Tags / Notes
                    </th>
                    {userRole !== "Viewer" && (
                      <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px] w-12 text-center">
                        Edit
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-600 text-xs font-mono bg-white">
                  {numbers.map((num) => {
                    const isChecked = selectedIds.includes(num.id);
                    return (
                      <tr
                        key={num.id}
                        className={`hover:bg-blue-50/30 transition duration-100 ${
                          isChecked ? "bg-blue-50/50 hover:bg-blue-50" : ""
                        }`}
                      >
                        {userRole !== "Viewer" && (
                          <td className="py-3 px-4">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => handleSelectRow(num.id)}
                              className="rounded text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer"
                            />
                          </td>
                        )}
                        <td className="py-3 px-4 font-bold max-w-[150px] truncate text-slate-700 font-sans" title={num.rawNumber}>
                          {num.rawNumber}
                        </td>
                        <td className="py-3 px-4 text-slate-800">
                          {num.formattedNumber ? (
                            <div>
                              <span className="font-bold font-mono text-slate-950">{num.formattedNumber}</span>
                              {(num.lineType || num.timezone) && (
                                <span className="block text-[10px] text-slate-400 font-sans mt-0.5">
                                  {num.lineType && <span className="font-semibold text-slate-500">{num.lineType}</span>}
                                  {num.lineType && num.timezone && " • "}
                                  {num.timezone && <span>{num.timezone.split(" ")[0]}</span>}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400 italic font-normal">Unprocessed</span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {num.hasWhatsApp === null ? (
                            <span className="text-slate-300 font-sans text-[10px]">-</span>
                          ) : num.hasWhatsApp ? (
                            <div className="relative group flex items-center gap-2">
                              {num.waProfilePic ? (
                                <img
                                  src={num.waProfilePic}
                                  alt="WhatsApp Avatar"
                                  className="w-6 h-6 rounded-full border border-emerald-200 object-cover shrink-0"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0 font-bold text-[8px]">
                                  WA
                                </div>
                              )}
                              <div className="flex flex-col text-[11px] leading-tight">
                                <span className="font-bold text-emerald-800 truncate max-w-[100px] font-sans">
                                  {num.waProfileName || "Active User"}
                                </span>
                                {num.waIsBusiness && (
                                  <span className="text-[9px] text-emerald-600 font-bold font-sans">Business</span>
                                )}
                              </div>

                              {/* Rich Hover Card Toolkit */}
                              <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block z-20 w-56 bg-slate-900 text-white p-3.5 rounded-xl shadow-xl border border-slate-700/80 font-sans text-xs space-y-2 animate-fade-in">
                                <div className="flex items-center gap-2.5">
                                  {num.waProfilePic ? (
                                    <img
                                      src={num.waProfilePic}
                                      alt="Avatar"
                                      className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center shrink-0 text-[10px] font-bold text-slate-300">
                                      WA
                                    </div>
                                  )}
                                  <div>
                                    <p className="font-bold text-slate-100">{num.waProfileName || "Active Contact"}</p>
                                    <p className="text-[10px] text-emerald-400 font-semibold font-mono">
                                      {num.waIsBusiness ? "WhatsApp Business" : "Personal Account"}
                                    </p>
                                  </div>
                                </div>
                                {num.waAboutText && (
                                  <p className="text-[10px] italic text-slate-300 border-t border-slate-800 pt-1.5 leading-relaxed">
                                    "{num.waAboutText}"
                                  </p>
                                )}
                                <div className="text-[9px] text-slate-500 font-mono flex items-center justify-between border-t border-slate-800 pt-1.5 mt-1.5">
                                  <span>Checked:</span>
                                  <span>{num.waCheckedAt ? new Date(num.waCheckedAt).toLocaleTimeString() : "-"}</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-slate-50 text-slate-400 px-2 py-0.5 rounded border border-slate-200/60 font-sans text-[10px]">
                              No Account
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-sans text-[11px] font-bold">
                          {num.isValid === null ? (
                            <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                              <Clock className="w-3 h-3" /> Pending
                            </span>
                          ) : num.isValid ? (
                            <span className="inline-flex items-center gap-1 bg-green-50 text-green-700 px-2 py-0.5 rounded border border-green-100">
                              <CheckCircle2 className="w-3 h-3" /> Valid
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-red-50 text-red-600 px-2 py-0.5 rounded border border-red-100">
                              <XCircle className="w-3 h-3" /> Invalid
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-sans text-xs text-slate-500 max-w-[180px] truncate" title={num.validationError || ""}>
                          {num.validationError || <span className="text-slate-300 font-mono">-</span>}
                        </td>
                        <td className="py-3 px-4">
                          {num.countryCode ? (
                            <span className="bg-slate-100 text-slate-600 text-[10px] px-2 py-0.5 rounded-full border border-slate-200 font-bold">
                              {num.countryCode}
                            </span>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="py-3 px-4 max-w-[200px]">
                          <div className="flex flex-col gap-1">
                            {/* Tags */}
                            {num.tags ? (
                              <div className="flex flex-wrap gap-1">
                                {num.tags.split(",").map((t: string) => t.trim()).filter(Boolean).map((tag: string, idx: number) => (
                                  <span
                                    key={idx}
                                    className="px-1.5 py-0.5 bg-blue-50 text-blue-600 text-[9px] rounded font-sans font-bold border border-blue-100/50"
                                  >
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            ) : null}
                            {/* Notes */}
                            {num.notes ? (
                              <span
                                className="text-[11px] text-slate-500 font-sans truncate block max-w-[180px]"
                                title={num.notes}
                              >
                                {num.notes}
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-300 italic font-sans">-</span>
                            )}
                          </div>
                        </td>
                        {userRole !== "Viewer" && (
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => {
                                setEditingNumber(num);
                                setEditNotes(num.notes || "");
                                setEditTags(num.tags || "");
                              }}
                              className="p-1 hover:bg-slate-100 text-slate-500 hover:text-slate-800 rounded transition cursor-pointer inline-block"
                              title="Edit custom tags and notes"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>

          {/* Fast Pagination footer */}
          <div className="px-6 border-t border-slate-100 pt-4 flex flex-col sm:flex-row justify-between items-center gap-3 bg-white">
            <div className="flex items-center gap-2 text-xs text-slate-500 font-sans">
              <span>View limit:</span>
              <select
                value={limit}
                onChange={(e) => {
                  setLimit(parseInt(e.target.value));
                  setPage(1);
                  setSelectedIds([]);
                }}
                className="bg-white border border-slate-200 rounded px-1.5 py-1 outline-none text-slate-700 focus:border-blue-500 cursor-pointer shadow-sm"
              >
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value={250}>250</option>
              </select>
            </div>

            <div className="flex items-center gap-3 bg-white">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-1.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 rounded-lg transition cursor-pointer shadow-sm"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono text-xs text-slate-600 font-semibold">
                Page {page} of {totalPages || 1}
              </span>
              <button
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page >= totalPages}
                className="p-1.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 rounded-lg transition cursor-pointer shadow-sm"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Diagnostics Logs Panel */}
        <div className="xl:col-span-4 flex flex-col bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden py-5 h-[620px]">
          <div className="px-5 pb-3 border-b border-slate-200 flex items-center justify-between bg-white">
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-blue-500" /> Audit Logging
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5 font-mono">
                Real-time validation diagnostic logs
              </p>
            </div>
            <button
              onClick={handleDownloadLogs}
              title="Download full diagnostics file"
              className="p-1.5 bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-lg transition cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Logs feed scrolling wrapper */}
          <div className="flex-1 overflow-y-auto p-5 space-y-2.5 font-mono text-[10px] leading-relaxed bg-slate-50/50">
            {logs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400">
                <Clock className="w-6 h-6 mb-1 text-slate-300" />
                No logs recorded yet.
              </div>
            ) : (
              logs.map((log) => {
                let badgeColor = "bg-slate-100 text-slate-600 border border-slate-200";
                if (log.level === "ERROR") badgeColor = "bg-red-50 text-red-600 border border-red-100";
                else if (log.level === "WARNING") badgeColor = "bg-amber-50 text-amber-700 border border-amber-100";
                else if (log.level === "INFO") badgeColor = "bg-blue-50 text-blue-600 border border-blue-100";

                return (
                  <div key={log.id} className="p-2.5 bg-white border border-slate-100 rounded-lg shadow-sm">
                    <div className="flex items-center justify-between mb-1 text-[9px] text-slate-400">
                      <span>{log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : ""}</span>
                      <span className={`px-1.5 py-0.2 rounded font-bold text-[8px] uppercase tracking-wide ${badgeColor}`}>
                        {log.level}
                      </span>
                    </div>
                    <p className="text-slate-700 leading-normal font-mono">{log.message}</p>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
      {/* Metadata Editor Modal Overlay */}
      {editingNumber && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50/75">
              <h4 className="font-bold text-slate-900 text-sm tracking-tight flex items-center gap-1.5">
                <Edit className="w-4 h-4 text-indigo-600" /> Edit Metadata & Notes
              </h4>
              <p className="text-[11px] text-slate-500 mt-1 font-mono">
                Record: {editingNumber.formattedNumber || editingNumber.rawNumber}
              </p>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Custom Tags
                </label>
                <input
                  type="text"
                  placeholder="e.g. VIP, Landline, Lead, Followup"
                  value={editTags}
                  onChange={(e) => setEditTags(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition font-sans shadow-xs"
                />
                <span className="text-[10px] text-slate-400 mt-1 block leading-relaxed font-sans">
                  Comma-separated tags to filter or segment records easily.
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Custom Notes
                </label>
                <textarea
                  placeholder="Enter details, timezone availability, account status notes..."
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  rows={4}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition font-sans shadow-xs resize-none"
                />
              </div>
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                onClick={() => setEditingNumber(null)}
                className="bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-4 py-2 rounded-lg text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveMetadata}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-lg text-xs transition cursor-pointer shadow-sm"
              >
                Save Details
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
