import React, { useState, useRef, DragEvent, ChangeEvent } from "react";
import Papa from "papaparse";
import { UploadCloud, FileText, CheckCircle2, AlertCircle, Trash2, ArrowLeft, Loader2 } from "lucide-react";

interface SessionUploadProps {
  onBackToDashboard: () => void;
  onUploadSuccess: (name: string, rawNumbers: string[]) => Promise<void>;
}

export default function SessionUpload({ onBackToDashboard, onUploadSuccess }: SessionUploadProps) {
  const [activeTab, setActiveTab] = useState<"file" | "paste">("file");
  const [pastedText, setPastedText] = useState("");
  const [isDragActive, setIsDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [parsedNumbers, setParsedNumbers] = useState<string[]>([]);
  const [sessionName, setSessionName] = useState("");
  const [previewList, setPreviewList] = useState<string[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [uniqueCount, setUniqueCount] = useState(0);
  const [dupCount, setDupCount] = useState(0);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePasteChange = (text: string) => {
    setPastedText(text);
    if (!text.trim()) {
      setParsedNumbers([]);
      setPreviewList([]);
      setTotalCount(0);
      setUniqueCount(0);
      setDupCount(0);
      return;
    }

    if (!sessionName || sessionName.startsWith("Quick Paste")) {
      const prettyDate = new Date().toLocaleDateString("en-GB", { day: 'numeric', month: 'short' });
      setSessionName(`Quick Paste (${prettyDate})`);
    }

    processRawText(text, false);
  };

  // Parse text or CSV content
  const processRawText = (text: string, isCsv: boolean) => {
    setError(null);
    let numbers: string[] = [];

    if (isCsv) {
      // Parse CSV
      const parsed = Papa.parse(text, { skipEmptyLines: true });
      const data = parsed.data as string[][];

      if (data.length > 0) {
        // Find best column index (containing phone numbers)
        // Check headers (row 0)
        const headers = data[0].map((h) => String(h).toLowerCase().trim());
        const targetKeywords = ["phone", "number", "tel", "mobile", "phone_number", "phonenumber"];
        
        let targetColIndex = 0;
        for (let i = 0; i < headers.length; i++) {
          if (targetKeywords.some((kw) => headers[i].includes(kw))) {
            targetColIndex = i;
            break;
          }
        }

        // Extract numbers
        // If row 0 looks like header, skip it. If it doesn't, include it.
        const startRow = headers.some((h) => targetKeywords.some((kw) => h.includes(kw))) ? 1 : 0;
        
        for (let r = startRow; r < data.length; r++) {
          if (data[r][targetColIndex]) {
            numbers.push(String(data[r][targetColIndex]).trim());
          }
        }
      }
    } else {
      // Parse TXT split by lines or commas
      numbers = text
        .split(/[\r\n,]+/)
        .map((num) => num.trim())
        .filter(Boolean);
    }

    if (numbers.length === 0) {
      setError("No numbers could be parsed from this file. Ensure it contains a list of digits.");
      return;
    }

    if (numbers.length > 10000) {
      setError(`File contains ${numbers.length.toLocaleString()} numbers. The maximum allowed limit is 10,000 phone numbers per dataset.`);
      setParsedNumbers([]);
      return;
    }

    const unique = Array.from(new Set(numbers));
    
    setTotalCount(numbers.length);
    setUniqueCount(unique.length);
    setDupCount(numbers.length - unique.length);
    setParsedNumbers(numbers);
    setPreviewList(unique.slice(0, 10)); // Top 10 for preview
  };

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    const isCsv = file.name.endsWith(".csv");
    const isTxt = file.name.endsWith(".txt");

    if (!isCsv && !isTxt) {
      setError("Unsupported file format. Only CSV (.csv) and Text (.txt) formats are supported.");
      return;
    }

    setFileName(file.name);
    // Autofill suggested session name based on file name
    const cleanName = file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");
    const prettyDate = new Date().toLocaleDateString("en-GB", { day: 'numeric', month: 'short' });
    setSessionName(`${cleanName} (${prettyDate})`);

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      processRawText(content, isCsv);
    };
    reader.onerror = () => {
      setError("Failed to read file contents.");
    };
    reader.readAsText(file);
  };

  const handleClearFile = () => {
    setFileName(null);
    setPastedText("");
    setParsedNumbers([]);
    setPreviewList([]);
    setSessionName("");
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleUploadSubmit = async () => {
    if (parsedNumbers.length === 0) return;
    if (!sessionName.trim()) {
      setError("Please specify a descriptive dataset name.");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await onUploadSuccess(sessionName.trim(), parsedNumbers);
    } catch (err: any) {
      setError(err?.message || "Failed to create dataset in backend.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="upload_view" className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 animate-fade-in">
        <button
          onClick={onBackToDashboard}
          className="p-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-600 transition cursor-pointer shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Import Phone Dataset</h2>
          <p className="text-slate-500 text-xs mt-0.5">
            Parse, analyze, and queue up to 10,000 numbers from standard CSV or plain TXT files.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-6">
        {error && (
          <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2 leading-relaxed">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
            <span>{error}</span>
          </div>
        )}

        {/* Tab switcher */}
        {!fileName && (
          <div className="flex border-b border-slate-100 pb-1 gap-2">
            <button
              onClick={() => { setActiveTab("file"); handleClearFile(); }}
              className={`pb-3 px-4 font-bold text-xs transition border-b-2 cursor-pointer ${
                activeTab === "file"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-slate-400 hover:text-slate-600"
              }`}
            >
              Upload CSV or TXT File
            </button>
            <button
              onClick={() => { setActiveTab("paste"); handleClearFile(); }}
              className={`pb-3 px-4 font-bold text-xs transition border-b-2 cursor-pointer ${
                activeTab === "paste"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-slate-400 hover:text-slate-600"
              }`}
            >
              Copy & Paste Raw Numbers
            </button>
          </div>
        )}

        {/* Drag and Drop Zone or Paste Textarea */}
        {!fileName ? (
          activeTab === "file" ? (
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center flex flex-col items-center justify-center gap-3 transition-all duration-200 cursor-pointer ${
                isDragActive
                  ? "border-blue-500 bg-blue-50/50 text-slate-800"
                  : "border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-slate-100/50 text-slate-500"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".csv,.txt"
                className="hidden"
              />
              <div className="p-4 bg-white rounded-xl border border-slate-200 text-blue-500 shadow-sm">
                <UploadCloud className="w-8 h-8" />
              </div>
              <div>
                <p className="text-slate-800 text-sm font-bold">Drag & drop your dataset file here</p>
                <p className="text-slate-500 text-xs mt-1">or click to browse your local files</p>
              </div>
              <span className="text-[10px] text-slate-500 font-mono mt-2 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-sm">
                CSV or TXT formats (up to 10k phone numbers)
              </span>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Paste Phone Numbers</label>
                <textarea
                  rows={6}
                  placeholder="Paste numbers here, one per line, or separated by commas. (e.g.&#10;+15551234567&#10;+447123456789&#10;919876543210)"
                  value={pastedText}
                  onChange={(e) => handlePasteChange(e.target.value)}
                  className="w-full bg-slate-50 text-slate-800 text-xs font-mono border border-slate-200 rounded-xl px-4 py-3 focus:bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none shadow-inner resize-y leading-relaxed"
                />
              </div>
              {parsedNumbers.length > 0 && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-5 animate-fade-in">
                  {/* Analysis Stats */}
                  <div className="grid grid-cols-3 gap-4 border border-slate-200 py-4 bg-white rounded-xl px-4 shadow-sm">
                    <div className="text-center">
                      <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Raw Items</span>
                      <span className="text-lg font-bold text-slate-800 font-mono mt-1 block">
                        {totalCount.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-center border-l border-r border-slate-200">
                      <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Unique Queue</span>
                      <span className="text-lg font-bold text-green-600 font-mono mt-1 block">
                        {uniqueCount.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-center">
                      <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Duplicates</span>
                      <span className="text-lg font-bold text-amber-600 font-mono mt-1 block">
                        {dupCount.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Custom Session Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 block">Dataset Queue Name</label>
                    <input
                      type="text"
                      placeholder="Give this dataset a descriptive name"
                      value={sessionName}
                      onChange={(e) => setSessionName(e.target.value)}
                      className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg px-3.5 py-2.5 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none font-sans shadow-sm"
                    />
                  </div>

                  {/* Top 10 Preview Scroll */}
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      Parsed List Preview (Top 10 rows)
                    </span>
                    <div className="bg-white border border-slate-200 rounded-lg p-3 max-h-40 overflow-y-auto divide-y divide-slate-100 font-mono text-xs text-slate-600 shadow-inner">
                      {previewList.map((num, idx) => (
                        <div key={idx} className="py-1.5 flex justify-between">
                          <span className="text-[10px] text-slate-400">Row {idx + 1}</span>
                          <span className="font-semibold text-slate-700">{num}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-3 justify-end pt-2">
                    <button
                      onClick={handleClearFile}
                      className="bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-4 py-2.5 rounded-lg text-xs transition cursor-pointer shadow-sm"
                    >
                      Clear Input
                    </button>
                    <button
                      onClick={handleUploadSubmit}
                      disabled={loading || parsedNumbers.length === 0}
                      className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg text-xs transition shadow-sm cursor-pointer disabled:opacity-50"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" /> Saving...
                        </>
                      ) : (
                        <>
                          Create Validation Session
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )
        ) : (
          /* File Uploaded Preview Card */
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white text-blue-500 border border-slate-200 rounded-lg shadow-sm">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{fileName}</h4>
                  <p className="text-[10px] text-slate-400 font-mono">
                    File uploaded & parsed successfully
                  </p>
                </div>
              </div>
              <button
                onClick={handleClearFile}
                className="p-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 rounded-lg transition cursor-pointer text-xs"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            {/* Analysis Stats */}
            <div className="grid grid-cols-3 gap-4 border-t border-b border-slate-200 py-4 bg-white/50 rounded-lg px-4 border">
              <div className="text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Raw Items</span>
                <span className="text-lg font-bold text-slate-800 font-mono mt-1 block">
                  {totalCount.toLocaleString()}
                </span>
              </div>
              <div className="text-center border-l border-r border-slate-200">
                <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Unique Queue</span>
                <span className="text-lg font-bold text-green-600 font-mono mt-1 block">
                  {uniqueCount.toLocaleString()}
                </span>
              </div>
              <div className="text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Duplicates</span>
                <span className="text-lg font-bold text-amber-600 font-mono mt-1 block">
                  {dupCount.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Custom Session Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">Dataset Queue Name</label>
              <input
                type="text"
                placeholder="Give this dataset a descriptive name (e.g. Leads campaign)"
                value={sessionName}
                onChange={(e) => setSessionName(e.target.value)}
                className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg px-3.5 py-2.5 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none font-sans shadow-sm"
              />
            </div>

            {/* Top 10 Preview Scroll */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Raw List Preview (Top 10 rows)
              </span>
              <div className="bg-white border border-slate-200 rounded-lg p-3 max-h-40 overflow-y-auto divide-y divide-slate-100 font-mono text-xs text-slate-600 shadow-inner">
                {previewList.map((num, idx) => (
                  <div key={idx} className="py-1.5 flex justify-between">
                    <span className="text-[10px] text-slate-400">Row {idx + 1}</span>
                    <span className="font-semibold text-slate-700">{num}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 justify-end pt-2">
              <button
                onClick={handleClearFile}
                className="bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-4 py-2.5 rounded-lg text-xs transition cursor-pointer shadow-sm"
              >
                Reset Upload
              </button>
              <button
                onClick={handleUploadSubmit}
                disabled={loading || parsedNumbers.length === 0}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg text-xs transition shadow-sm cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Saving Dataset...
                  </>
                ) : (
                  <>
                    Create Validation Session
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
