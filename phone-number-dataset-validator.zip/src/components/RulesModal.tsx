import React, { useState, useEffect } from "react";
import { X, SlidersHorizontal, CheckCircle2, ShieldAlert } from "lucide-react";
import { UserRole } from "../types.ts";

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  userRole: UserRole;
}

export default function RulesModal({ isOpen, onClose, token, userRole }: RulesModalProps) {
  const [strictCountryCheck, setStrictCountryCheck] = useState(true);
  const [strictAreaCodeCheck, setStrictAreaCodeCheck] = useState(true);
  const [carrierPrefixCheck, setCarrierPrefixCheck] = useState(true);
  const [allowedCountries, setAllowedCountries] = useState<string[]>(["US/CA", "UK", "DE", "FR", "IN", "AU"]);
  
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const availableCountries = [
    { iso: "US/CA", name: "United States/Canada (+1)" },
    { iso: "UK", name: "United Kingdom (+44)" },
    { iso: "FR", name: "France (+33)" },
    { iso: "DE", name: "Germany (+49)" },
    { iso: "IN", name: "India (+91)" },
    { iso: "AU", name: "Australia (+61)" },
  ];

  useEffect(() => {
    if (isOpen && token) {
      fetchRules();
    }
  }, [isOpen, token]);

  const fetchRules = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/validation/config", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const config = await res.json();
        setStrictCountryCheck(config.strictCountryCheck);
        setStrictAreaCodeCheck(config.strictAreaCodeCheck);
        setCarrierPrefixCheck(config.carrierPrefixCheck);
        setAllowedCountries(config.allowedCountries || []);
      }
    } catch (err) {
      console.error("Failed to fetch rules:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCountryToggle = (iso: string) => {
    if (allowedCountries.includes(iso)) {
      setAllowedCountries(allowedCountries.filter((c) => c !== iso));
    } else {
      setAllowedCountries([...allowedCountries, iso]);
    }
  };

  const handleSave = async () => {
    if (!token) return;
    setSaving(true);
    setStatusMsg(null);
    try {
      const res = await fetch("/api/validation/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          strictCountryCheck,
          strictAreaCodeCheck,
          carrierPrefixCheck,
          allowedCountries,
        }),
      });

      if (res.ok) {
        setStatusMsg({ type: "success", text: "Validation rules updated successfully. Future validation runs will apply these configurations." });
        setTimeout(() => {
          onClose();
          setStatusMsg(null);
        }, 1800);
      } else {
        const data = await res.json();
        setStatusMsg({ type: "error", text: data.error || "Failed to save configuration." });
      }
    } catch (err) {
      console.error("Failed to save rules:", err);
      setStatusMsg({ type: "error", text: "Network error. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  const isEditable = userRole === "Admin" || userRole === "Uploader";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm">Validation Engine Rules</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded-full hover:bg-slate-200 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {statusMsg && (
            <div className={`p-4 rounded-xl border flex items-start gap-3 text-xs leading-relaxed ${
              statusMsg.type === "success" 
                ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
                : "bg-red-50 border-red-200 text-red-800"
            }`}>
              {statusMsg.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              )}
              <span>{statusMsg.text}</span>
            </div>
          )}

          {!isEditable && (
            <div className="bg-amber-50 border border-amber-100 p-3.5 rounded-xl flex gap-3 text-xs text-amber-800">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p>
                <strong>View-Only Mode:</strong> Your active role is <strong>{userRole}</strong>. Only <strong>Admins</strong> and <strong>Uploaders</strong> can modify rules.
              </p>
            </div>
          )}

          {loading ? (
            <div className="py-12 text-center text-slate-400 font-mono text-xs">Loading rules config...</div>
          ) : (
            <>
              {/* Checkboxes */}
              <div className="space-y-4">
                {/* 1. Strict Country Code Check */}
                <label className="flex items-start gap-3.5 p-3 rounded-xl border border-slate-100 hover:bg-slate-50 cursor-pointer transition">
                  <input
                    type="checkbox"
                    checked={strictCountryCheck}
                    disabled={!isEditable}
                    onChange={(e) => setStrictCountryCheck(e.target.checked)}
                    className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded cursor-pointer"
                  />
                  <div>
                    <span className="font-semibold text-slate-900 text-xs block">Strict Country Code Checks</span>
                    <span className="text-slate-500 text-[11px] mt-0.5 block leading-relaxed">
                      Reject phone numbers if the country code is not found, invalid, or absent from the allowed list.
                    </span>
                  </div>
                </label>

                {/* 2. Strict Area Code Validity */}
                <label className="flex items-start gap-3.5 p-3 rounded-xl border border-slate-100 hover:bg-slate-50 cursor-pointer transition">
                  <input
                    type="checkbox"
                    checked={strictAreaCodeCheck}
                    disabled={!isEditable}
                    onChange={(e) => setStrictAreaCodeCheck(e.target.checked)}
                    className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded cursor-pointer"
                  />
                  <div>
                    <span className="font-semibold text-slate-900 text-xs block">Common Area Code Checks</span>
                    <span className="text-slate-500 text-[11px] mt-0.5 block leading-relaxed">
                      Enforce regional area code numbering plans (e.g. +1 US exchange prefixes cannot start with 0 or 1, and UK mobile prefixes must match national routing prefixes).
                    </span>
                  </div>
                </label>

                {/* 3. Carrier Prefix identification */}
                <label className="flex items-start gap-3.5 p-3 rounded-xl border border-slate-100 hover:bg-slate-50 cursor-pointer transition">
                  <input
                    type="checkbox"
                    checked={carrierPrefixCheck}
                    disabled={!isEditable}
                    onChange={(e) => setCarrierPrefixCheck(e.target.checked)}
                    className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded cursor-pointer"
                  />
                  <div>
                    <span className="font-semibold text-slate-900 text-xs block">Carrier Prefix Identification</span>
                    <span className="text-slate-500 text-[11px] mt-0.5 block leading-relaxed">
                      Identify the network carrier (e.g. AT&T, Vodafone, O2, Orange, Jio, Telstra) based on national mobile prefix ranges.
                    </span>
                  </div>
                </label>
              </div>

              {/* Country Selection Checklist */}
              {strictCountryCheck && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h4 className="font-semibold text-slate-900 text-xs">Allowed Validation Country Codes</h4>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Select countries that the validation engine is allowed to accept. Any numbers outside of these chosen regions will be flagged as invalid.
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {availableCountries.map((country) => {
                      const isChecked = allowedCountries.includes(country.iso);
                      return (
                        <label
                          key={country.iso}
                          className={`flex items-center gap-2 p-2.5 rounded-lg border text-xs cursor-pointer transition ${
                            isChecked
                              ? "bg-blue-50/50 border-blue-200 text-blue-800 font-medium"
                              : "border-slate-100 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            disabled={!isEditable}
                            onChange={() => handleCountryToggle(country.iso)}
                            className="h-3.5 w-3.5 text-blue-600 border-slate-300 rounded cursor-pointer"
                          />
                          <span className="truncate">{country.name}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs transition cursor-pointer"
          >
            Cancel
          </button>
          {isEditable && (
            <button
              onClick={handleSave}
              disabled={saving || loading}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold rounded-lg text-xs shadow-sm transition cursor-pointer disabled:opacity-50"
            >
              {saving ? "Saving Changes..." : "Save Settings"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
