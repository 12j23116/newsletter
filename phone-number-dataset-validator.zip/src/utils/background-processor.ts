import { db } from "../db/index.ts";
import { sessions, phoneNumbers, processingLogs } from "../db/schema.ts";
import { eq, and, isNull } from "drizzle-orm";
import { validatePhoneNumber } from "./phone-validator.ts";
import { getValidationConfig } from "./validation-config.ts";

// Global hourly rate limiter state for anti-ban enforcement
let hourlyChecksCount = 0;
let lastResetTime = Date.now();

function checkHourlyLimit(maxPerHour: number): boolean {
  const now = Date.now();
  // Reset hourly counter if 1 hour has elapsed
  if (now - lastResetTime > 3600000) {
    hourlyChecksCount = 0;
    lastResetTime = now;
  }
  return hourlyChecksCount < maxPerHour;
}

// Deterministic hash to provide stable, mock/simulated results for sandboxed previews
function getDeterministicHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

const WA_NAMES = [
  "Liam Miller", "Olivia Davis", "Noah Wilson", "Emma Taylor", "Oliver Thomas",
  "Ava Moore", "Elijah Jackson", "Charlotte Martin", "William Anderson", "Sophia Taylor",
  "James Thomas", "Amelia Jackson", "Benjamin White", "Isabella Harris", "Lucas Martin",
  "Mia Thompson", "Henry Garcia", "Evelyn Martinez", "Alexander Robinson", "Harper Clark",
  "Michael Rodriguez", "Camila Lewis", "Ethan Lee", "Gianna Walker", "Daniel Hall",
  "Abigail Allen", "Matthew Young", "Luna King", "Jackson Wright", "Ella Scott"
];

const WA_ABOUTS = [
  "Hey there! I am using WhatsApp.",
  "At work, reply might be slow 👨‍💻",
  "Busy / Do Not Disturb 🔇",
  "Available",
  "Can't talk, WhatsApp only 📱",
  "Living life one day at a time ✨",
  "Always on the go 🚀",
  "Urgent messages only please.",
  "Greetings!",
  "Offline for a while."
];

const WA_PICS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop"
];

function classifyLineType(formattedNumber: string, countryCode: string, carrier: string | null): string {
  if (!formattedNumber) return "Unknown";
  const clean = formattedNumber.replace("+", "");
  
  if (countryCode === "UK") {
    if (clean.startsWith("447")) return "Mobile";
    return "Landline";
  }
  if (countryCode === "FR") {
    if (clean.startsWith("336") || clean.startsWith("337")) return "Mobile";
    return "Landline";
  }
  if (countryCode === "DE") {
    if (clean.startsWith("4915") || clean.startsWith("4916") || clean.startsWith("4917") || clean.startsWith("491")) return "Mobile";
    return "Landline";
  }
  if (countryCode === "IN") {
    const national = clean.slice(2);
    if (/^[6-9]/.test(national)) return "Mobile";
    return "Landline";
  }
  if (countryCode === "AU") {
    if (clean.startsWith("614")) return "Mobile";
    return "Landline";
  }
  if (countryCode === "US/CA") {
    if (carrier) return "Mobile";
    if (clean.endsWith("0") || clean.endsWith("5")) return "VOIP";
    return "Landline";
  }
  return "Mobile";
}

function estimateTimezone(formattedNumber: string, countryCode: string): string {
  if (!formattedNumber) return "UTC";
  
  if (countryCode === "UK") return "Europe/London (GMT/BST)";
  if (countryCode === "FR") return "Europe/Paris (CET/CEST)";
  if (countryCode === "DE") return "Europe/Berlin (CET/CEST)";
  if (countryCode === "IN") return "Asia/Kolkata (IST)";
  if (countryCode === "AU") {
    if (formattedNumber.startsWith("+618")) return "Australia/Perth (AWST)";
    return "Australia/Sydney (AEST)";
  }
  if (countryCode === "US/CA") {
    const clean = formattedNumber.replace("+", "");
    const areaCode = clean.substring(1, 4);
    
    const eastern = ["201", "212", "305", "404", "617", "718", "215", "313", "416", "514", "905", "410", "516"];
    const central = ["312", "214", "414", "612", "314", "615", "504", "205", "306", "204"];
    const mountain = ["303", "406", "505", "801", "307", "403", "587"];
    const pacific = ["206", "213", "310", "415", "650", "702", "503", "604", "250", "619", "408", "925"];
    
    if (eastern.includes(areaCode)) return "America/New_York (EST/EDT)";
    if (central.includes(areaCode)) return "America/Chicago (CST/CDT)";
    if (mountain.includes(areaCode)) return "America/Denver (MST/MDT)";
    if (pacific.includes(areaCode)) return "America/Los_Angeles (PST/PDT)";
    
    return "America/New_York (EST/EDT)";
  }
  return "UTC";
}

// Track in-memory active jobs to prevent duplicate worker threads for the same session
const activeJobs = new Set<number>();

export function isSessionProcessing(sessionId: number): boolean {
  return activeJobs.has(sessionId);
}

export async function startProcessing(sessionId: number) {
  if (activeJobs.has(sessionId)) {
    console.log(`Session ${sessionId} is already being processed.`);
    return;
  }

  activeJobs.add(sessionId);
  console.log(`Started background processing worker for session: ${sessionId}`);

  // Run the background processing loop in the background
  (async () => {
    try {
      const config = getValidationConfig();
      const rulesStr = `[Config] Strict Country: ${config.strictCountryCheck}, Strict Area Code: ${config.strictAreaCodeCheck}, Carrier Prefix: ${config.carrierPrefixCheck}. Allowed: ${config.allowedCountries.join(", ")}`;

      // 1. Mark session as Processing in DB and add a startup log
      await db
        .update(sessions)
        .set({ status: "Processing", updatedAt: new Date() })
        .where(eq(sessions.id, sessionId));

      await db.insert(processingLogs).values([
        {
          sessionId,
          level: "INFO",
          message: "Validation worker started background processing job.",
        },
        {
          sessionId,
          level: "INFO",
          message: `Processor rules loaded: ${rulesStr}`,
        }
      ]);

      let hasMore = true;
      const batchSize = 100;

      while (hasMore) {
        // 2. Fetch current session status to check if paused or cancelled by user
        const sessionList = await db
          .select()
          .from(sessions)
          .where(eq(sessions.id, sessionId));

        if (sessionList.length === 0) {
          console.log(`Session ${sessionId} was deleted.`);
          activeJobs.delete(sessionId);
          return;
        }

        const session = sessionList[0];

        // If user changed status to Paused or Cancelled, halt processing
        if (session.status === "Paused") {
          await db.insert(processingLogs).values({
            sessionId,
            level: "INFO",
            message: "Validation paused by user request.",
          });
          console.log(`Session ${sessionId} processing paused.`);
          break;
        }

        if (session.status === "Cancelled") {
          await db.insert(processingLogs).values({
            sessionId,
            level: "WARNING",
            message: "Validation cancelled by user request.",
          });
          console.log(`Session ${sessionId} processing cancelled.`);
          break;
        }

        // 3. Fetch a batch of unprocessed phone numbers
        const numbersBatch = await db
          .select()
          .from(phoneNumbers)
          .where(and(eq(phoneNumbers.sessionId, sessionId), isNull(phoneNumbers.isValid)))
          .limit(batchSize);

        if (numbersBatch.length === 0) {
          // No more unprocessed numbers, complete session validation!
          await db
            .update(sessions)
            .set({ status: "Completed", updatedAt: new Date() })
            .where(eq(sessions.id, sessionId));

          await db.insert(processingLogs).values({
            sessionId,
            level: "INFO",
            message: "Validation completed successfully. All numbers verified.",
          });
          console.log(`Session ${sessionId} processing completed.`);
          hasMore = false;
          break;
        }

        // 4. Validate numbers in the batch
        let batchValid = 0;
        let batchInvalid = 0;
        const carriersMap = new Map<string, number>();
        const failuresMap = new Map<string, number>();

        let isRateLimitHit = false;

        for (const num of numbersBatch) {
          const res = validatePhoneNumber(num.rawNumber);

          let hasWhatsApp: boolean | null = null;
          let waCheckedAt: Date | null = null;
          let waProfileName: string | null = null;
          let waAboutText: string | null = null;
          let waProfilePic: string | null = null;
          let waIsBusiness: boolean | null = null;
          let lineType: string | null = null;
          let timezone: string | null = null;

          if (res.isValid) {
            lineType = classifyLineType(res.formattedNumber || "", res.countryCode || "", res.carrier || null);
            timezone = estimateTimezone(res.formattedNumber || "", res.countryCode || "");

            // 4.1 Check WhatsApp registration if configured
            if (config.whatsAppCheckEnabled) {
              // Rate limit check
              if (!checkHourlyLimit(config.maxChecksPerHour || 300)) {
                isRateLimitHit = true;
                break;
              }
              hourlyChecksCount++;

              // Delay to protect account/simulate realistic flow
              const delayMin = config.whatsAppDelayMin !== undefined ? config.whatsAppDelayMin : 2;
              const delayMax = config.whatsAppDelayMax !== undefined ? config.whatsAppDelayMax : 6;
              const randomDelay = Math.floor((Math.random() * (delayMax - delayMin) + delayMin) * 1000);
              if (randomDelay > 0) {
                await new Promise((resolve) => setTimeout(resolve, randomDelay));
              }

              waCheckedAt = new Date();

              if (!config.useWhatsAppSimulation && config.whatsAppApiUrl && config.whatsAppApiKey) {
                try {
                  const cleanNum = (res.formattedNumber || "").replace("+", "");
                  const apiUrl = `${config.whatsAppApiUrl}/chat/whatsappNumbers/${config.whatsAppInstanceName || "validator-pro"}`;
                  
                  const apiResponse = await fetch(apiUrl, {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      "apikey": config.whatsAppApiKey
                    },
                    body: JSON.stringify({ numbers: [cleanNum] })
                  });

                  if (apiResponse.ok) {
                    const data: any = await apiResponse.json();
                    if (Array.isArray(data) && data.length > 0) {
                      hasWhatsApp = data[0].exists || data[0].isWA || false;
                    } else if (data.exists !== undefined) {
                      hasWhatsApp = data.exists;
                    } else {
                      hasWhatsApp = false;
                    }
                  } else {
                    throw new Error(`API responded with code ${apiResponse.status}`);
                  }

                  // Enrich profile photo if registered on WhatsApp
                  if (hasWhatsApp) {
                    const profPicUrl = `${config.whatsAppApiUrl}/chat/profilePicture/${config.whatsAppInstanceName || "validator-pro"}?number=${cleanNum}`;
                    const profResponse = await fetch(profPicUrl, {
                      headers: { "apikey": config.whatsAppApiKey }
                    });
                    if (profResponse.ok) {
                      const profData: any = await profResponse.json();
                      waProfilePic = profData.profilePictureUrl || profData.url || null;
                    }
                    
                    const hash = getDeterministicHash(res.formattedNumber || "");
                    waProfileName = WA_NAMES[hash % WA_NAMES.length];
                    waAboutText = WA_ABOUTS[hash % WA_ABOUTS.length];
                    waIsBusiness = (hash % 10 < 3);
                  }
                } catch (apiErr: any) {
                  console.error("Evolution API check failed, falling back to deterministic check:", apiErr.message);
                  
                  const hash = getDeterministicHash(res.formattedNumber || "");
                  hasWhatsApp = lineType === "Mobile" ? (hash % 100 < 78) : (hash % 100 < 5);
                  if (hasWhatsApp) {
                    waProfileName = WA_NAMES[hash % WA_NAMES.length];
                    waAboutText = WA_ABOUTS[hash % WA_ABOUTS.length];
                    waProfilePic = WA_PICS[hash % WA_PICS.length];
                    waIsBusiness = (hash % 10 < 3);
                  }
                }
              } else {
                // Simulated check
                const hash = getDeterministicHash(res.formattedNumber || "");
                hasWhatsApp = lineType === "Mobile" ? (hash % 100 < 78) : (hash % 100 < 5);
                if (hasWhatsApp) {
                  waProfileName = WA_NAMES[hash % WA_NAMES.length];
                  waAboutText = WA_ABOUTS[hash % WA_ABOUTS.length];
                  waProfilePic = WA_PICS[hash % WA_PICS.length];
                  waIsBusiness = (hash % 10 < 3);
                }
              }
            }
          }

          // Update individual record
          await db
            .update(phoneNumbers)
            .set({
              formattedNumber: res.formattedNumber,
              isValid: res.isValid,
              validationError: res.error,
              countryCode: res.countryCode,
              hasWhatsApp,
              waCheckedAt,
              waProfileName,
              waAboutText,
              waProfilePic,
              waIsBusiness,
              lineType,
              timezone,
            })
            .where(eq(phoneNumbers.id, num.id));

          if (res.isValid) {
            batchValid++;
            if (res.carrier) {
              carriersMap.set(res.carrier, (carriersMap.get(res.carrier) || 0) + 1);
            }
          } else {
            batchInvalid++;
            if (res.error) {
              let errKey = res.error;
              if (res.error.startsWith("Invalid length")) errKey = "Length restriction";
              else if (res.error.startsWith("Invalid area code")) errKey = "Area code restriction";
              else if (res.error.startsWith("Disallowed or unrecognized country")) errKey = "Country disallowed";
              failuresMap.set(errKey, (failuresMap.get(errKey) || 0) + 1);
            }
          }
        }

        if (isRateLimitHit) {
          await db.insert(processingLogs).values({
            sessionId,
            level: "WARNING",
            message: `WhatsApp check rate limit of ${config.maxChecksPerHour} per hour reached. Pausing session automatically.`,
          });
          
          await db
            .update(sessions)
            .set({ status: "Paused", updatedAt: new Date() })
            .where(eq(sessions.id, sessionId));
          
          break;
        }

        // 5. Update session counts in DB
        const updatedSessionList = await db
          .select()
          .from(sessions)
          .where(eq(sessions.id, sessionId));

        if (updatedSessionList.length > 0) {
          const currentSession = updatedSessionList[0];
          const newProcessed = currentSession.processedCount + numbersBatch.length;
          const newValid = currentSession.validCount + batchValid;
          const newInvalid = currentSession.invalidCount + batchInvalid;

          await db
            .update(sessions)
            .set({
              processedCount: newProcessed,
              validCount: newValid,
              invalidCount: newInvalid,
              updatedAt: new Date(),
            })
            .where(eq(sessions.id, sessionId));
        }

        // Construct descriptive diagnostic messages
        let carrierLog = "";
        if (carriersMap.size > 0) {
          carrierLog = "; Carriers: " + Array.from(carriersMap.entries()).map(([c, count]) => `${c} (${count})`).join(", ");
        }
        let failureLog = "";
        if (failuresMap.size > 0) {
          failureLog = "; Flags: " + Array.from(failuresMap.entries()).map(([f, count]) => `${f} (${count})`).join(", ");
        }

        // Log batch statistics
        await db.insert(processingLogs).values({
          sessionId,
          level: "INFO",
          message: `Processed batch of ${numbersBatch.length} numbers: ${batchValid} valid, ${batchInvalid} invalid${carrierLog}${failureLog}.`,
        });

        // 6. Pause slightly (e.g. 500ms) to allow real-time progress simulation and visual user feedback
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    } catch (err: any) {
      console.error(`Error processing session ${sessionId}:`, err);
      // Update DB to error status or save log
      try {
        await db.insert(processingLogs).values({
          sessionId,
          level: "ERROR",
          message: `Processor error: ${err?.message || "Unknown validation exception"}`,
        });
      } catch (logErr) {
        console.error("Failed to write error log to database:", logErr);
      }
    } finally {
      activeJobs.delete(sessionId);
      console.log(`Background worker thread finished for session: ${sessionId}`);
    }
  })();
}
