export interface CountryRule {
  iso: string;
  code: string;
  name: string;
  areaCodeRegex?: string; // Regex to validate area codes (without country code)
  carrierPrefixes?: { [prefix: string]: string }; // Prefix map to carrier names
  totalLength?: number[]; // Allowed digit lengths after country code
}

export interface ValidationConfig {
  strictCountryCheck: boolean;
  strictAreaCodeCheck: boolean;
  carrierPrefixCheck: boolean;
  allowedCountries: string[]; // List of ISO codes that are allowed
  // WhatsApp Settings
  whatsAppCheckEnabled: boolean;
  whatsAppApiUrl: string;
  whatsAppApiKey: string;
  whatsAppInstanceName: string;
  useWhatsAppSimulation: boolean;
  whatsAppDelayMin: number; // in seconds
  whatsAppDelayMax: number; // in seconds
  maxChecksPerHour: number;
  blacklistNumbers: string[]; // Global Blacklist / DNC List
}

// Default Configuration with rich, industry-standard E.164 rules
export let currentConfig: ValidationConfig = {
  strictCountryCheck: true,
  strictAreaCodeCheck: true,
  carrierPrefixCheck: true,
  allowedCountries: ["US/CA", "UK", "DE", "FR", "IN", "AU"],
  // WhatsApp Settings Defaults
  whatsAppCheckEnabled: true,
  whatsAppApiUrl: "",
  whatsAppApiKey: "",
  whatsAppInstanceName: "validator-pro",
  useWhatsAppSimulation: true,
  whatsAppDelayMin: 2,
  whatsAppDelayMax: 6,
  maxChecksPerHour: 300,
  blacklistNumbers: ["+15555555555", "+447700900000", "+919999999999"],
};

export const countryRules: { [iso: string]: CountryRule } = {
  "US/CA": {
    iso: "US/CA",
    code: "1",
    name: "United States/Canada",
    areaCodeRegex: "^[2-9]\\d{2}$", // Area codes cannot start with 0 or 1
    totalLength: [10],
    carrierPrefixes: {
      "201": "AT&T Mobility",
      "212": "Verizon Wireless",
      "310": "T-Mobile USA",
      "415": "Verizon Wireless",
      "650": "AT&T Mobility",
      "702": "Sprint/T-Mobile",
    }
  },
  "UK": {
    iso: "UK",
    code: "44",
    name: "United Kingdom",
    areaCodeRegex: "^(71|72|73|74|75|77|78|79|1|2)\\d*", // Mobile or standard landline area codes
    totalLength: [9, 10],
    carrierPrefixes: {
      "740": "EE Mobile",
      "741": "Vodafone UK",
      "750": "O2 UK",
      "751": "Three UK",
      "770": "Vodafone UK",
      "777": "EE Mobile",
      "780": "O2 UK",
      "790": "Three UK",
    }
  },
  "FR": {
    iso: "FR",
    code: "33",
    name: "France",
    areaCodeRegex: "^[1-9]$", // 1 to 9 (mobile is usually 6 or 7)
    totalLength: [9],
    carrierPrefixes: {
      "6": "Orange France",
      "7": "SFR / Bouygues Telecom",
    }
  },
  "DE": {
    iso: "DE",
    code: "49",
    name: "Germany",
    areaCodeRegex: "^(15|16|17|3|4|6|7|8|9)\\d*", // Mobile/Landline
    totalLength: [10, 11, 12],
    carrierPrefixes: {
      "15": "Deutsche Telekom",
      "16": "Vodafone Germany",
      "17": "O2 Germany (Telefónica)",
    }
  },
  "IN": {
    iso: "IN",
    code: "91",
    name: "India",
    areaCodeRegex: "^[6-9]\\d*$", // India mobile starts with 6, 7, 8, 9
    totalLength: [10],
    carrierPrefixes: {
      "98": "Airtel India",
      "99": "Vodafone Idea",
      "81": "Reliance Jio",
      "82": "Reliance Jio",
      "70": "Airtel India",
      "60": "BSNL Mobile",
    }
  },
  "AU": {
    iso: "AU",
    code: "61",
    name: "Australia",
    areaCodeRegex: "^(4|[2378])\\d*$", // 4 is mobile, 2,3,7,8 are regional landlines
    totalLength: [9],
    carrierPrefixes: {
      "41": "Telstra Mobile",
      "42": "Optus Mobile",
      "43": "Vodafone Australia",
      "44": "Telstra Mobile",
    }
  }
};

export function getValidationConfig(): ValidationConfig {
  return currentConfig;
}

export function updateValidationConfig(newConfig: Partial<ValidationConfig>): ValidationConfig {
  currentConfig = {
    ...currentConfig,
    ...newConfig,
  };
  return currentConfig;
}
