import { getValidationConfig, countryRules } from "./validation-config.ts";

export interface ValidationResult {
  isValid: boolean;
  formattedNumber: string;
  countryCode: string;
  carrier?: string | null;
  error: string | null;
}

export const COUNTRY_CODES = [
  { code: "971", iso: "AE", name: "United Arab Emirates" },
  { code: "380", iso: "UA", name: "Ukraine" },
  { code: "1", iso: "US/CA", name: "United States/Canada" },
  { code: "44", iso: "UK", name: "United Kingdom" },
  { code: "49", iso: "DE", name: "Germany" },
  { code: "33", iso: "FR", name: "France" },
  { code: "91", iso: "IN", name: "India" },
  { code: "61", iso: "AU", name: "Australia" },
  { code: "55", iso: "BR", name: "Brazil" },
  { code: "81", iso: "JP", name: "Japan" },
  { code: "86", iso: "CN", name: "China" },
  { code: "7", iso: "RU", name: "Russia" },
  { code: "34", iso: "ES", name: "Spain" },
  { code: "39", iso: "IT", name: "Italy" },
  { code: "52", iso: "MX", name: "Mexico" },
  { code: "27", iso: "ZA", name: "South Africa" },
  { code: "65", iso: "SG", name: "Singapore" },
  { code: "82", iso: "KR", name: "South Korea" },
  { code: "31", iso: "NL", name: "Netherlands" },
  { code: "41", iso: "CH", name: "Switzerland" },
];

export function validatePhoneNumber(raw: string): ValidationResult {
  if (!raw || typeof raw !== "string") {
    return {
      isValid: false,
      formattedNumber: "",
      countryCode: "Unknown",
      error: "Empty or invalid input type",
    };
  }

  // Trim spaces and remove common spacing chars like () -
  let cleaned = raw.trim().replace(/[\s\(\)\-\.]/g, "");

  if (cleaned.length === 0) {
    return {
      isValid: false,
      formattedNumber: "",
      countryCode: "Unknown",
      error: "Empty phone number after trimming",
    };
  }

  // Check for invalid characters
  const hasInvalidChars = /[^\d\+]/.test(cleaned);
  if (hasInvalidChars) {
    return {
      isValid: false,
      formattedNumber: cleaned,
      countryCode: "Unknown",
      error: "Contains invalid non-numeric characters",
    };
  }

  // Auto-format common local formats
  // 1. 10 digits without leading + or 1, e.g. "5551234567" -> +15551234567 (US/Canada)
  if (/^\d{10}$/.test(cleaned)) {
    cleaned = "+1" + cleaned;
  }
  // 2. UK style: Starts with 07 and has 11 digits, e.g. "07123456789" -> +447123456789
  else if (/^0[1-9]\d{9}$/.test(cleaned)) {
    if (cleaned.startsWith("07")) {
      cleaned = "+44" + cleaned.slice(1);
    } else if (cleaned.startsWith("0")) {
      cleaned = "+44" + cleaned.slice(1);
    }
  }
  // 3. E.164 missing + but starts with country code (e.g., "447123456789" or "15551234567" or "919876543210")
  else if (/^\d{11,14}$/.test(cleaned)) {
    let matched = false;
    for (const item of COUNTRY_CODES) {
      if (item.code !== "1" && cleaned.startsWith(item.code)) {
        cleaned = "+" + cleaned;
        matched = true;
        break;
      }
    }
    if (!matched && cleaned.length === 11 && cleaned.startsWith("1")) {
      cleaned = "+" + cleaned;
    }
  }

  // Must now start with '+' for E.164 check
  if (!cleaned.startsWith("+")) {
    return {
      isValid: false,
      formattedNumber: cleaned,
      countryCode: "Unknown",
      error: "Missing country code prefix (+)",
    };
  }

  const config = getValidationConfig();

  // Check if blacklisted
  if (config.blacklistNumbers && config.blacklistNumbers.includes(cleaned)) {
    return {
      isValid: false,
      formattedNumber: cleaned,
      countryCode: "Unknown",
      error: "Blacklisted number (Global DNC List)",
    };
  }

  // E.164 total length check (digits after + must be 7 to 15)
  const digitsOnly = cleaned.slice(1);
  if (digitsOnly.length < 7 || digitsOnly.length > 15) {
    return {
      isValid: false,
      formattedNumber: cleaned,
      countryCode: "Unknown",
      error: `Invalid length: E.164 requires 7 to 15 digits (got ${digitsOnly.length})`,
    };
  }

  // Determine Country Code from the plus-prefix
  let matchedCountry = "Unknown";
  let matchedCC = "";
  const sortedCC = [...COUNTRY_CODES].sort((a, b) => b.code.length - a.code.length);

  for (const cc of sortedCC) {
    if (digitsOnly.startsWith(cc.code)) {
      matchedCountry = cc.iso;
      matchedCC = cc.code;
      break;
    }
  }

  // 1. Check Country Code validity/allowance
  if (config.strictCountryCheck) {
    if (matchedCountry === "Unknown" || !config.allowedCountries.includes(matchedCountry)) {
      return {
        isValid: false,
        formattedNumber: cleaned,
        countryCode: matchedCountry,
        error: `Disallowed or unrecognized country code (+${digitsOnly.substring(0, 3)}...)`,
      };
    }
  }

  // Get national number (digits after country code)
  const nationalNumber = digitsOnly.slice(matchedCC.length);
  const rule = countryRules[matchedCountry];

  // 2. Validate digit lengths and area codes if country rule exists
  if (rule) {
    // Total Length Validation
    if (config.strictAreaCodeCheck && rule.totalLength) {
      if (!rule.totalLength.includes(nationalNumber.length)) {
        return {
          isValid: false,
          formattedNumber: cleaned,
          countryCode: matchedCountry,
          error: `Invalid length for ${rule.name}: expected ${rule.totalLength.join(" or ")} digits (got ${nationalNumber.length})`,
        };
      }
    }

    // Common Area Code Validity Check
    if (config.strictAreaCodeCheck && rule.areaCodeRegex) {
      const regex = new RegExp(rule.areaCodeRegex);
      
      // For US/CA, we match the first 3 digits of national number as the area code
      let areaCodeToTest = nationalNumber;
      if (matchedCountry === "US/CA") {
        areaCodeToTest = nationalNumber.substring(0, 3);
      }

      if (!regex.test(areaCodeToTest)) {
        return {
          isValid: false,
          formattedNumber: cleaned,
          countryCode: matchedCountry,
          error: `Invalid area code or local exchange prefix pattern for ${rule.name} (prefix: ${areaCodeToTest.substring(0, 4)})`,
        };
      }
    }
  }

  // 3. Carrier Prefix Identification
  let identifiedCarrier: string | null = null;
  if (config.carrierPrefixCheck && rule && rule.carrierPrefixes) {
    for (const prefix of Object.keys(rule.carrierPrefixes)) {
      if (nationalNumber.startsWith(prefix)) {
        identifiedCarrier = rule.carrierPrefixes[prefix];
        break;
      }
    }
  }

  return {
    isValid: true,
    formattedNumber: cleaned,
    countryCode: matchedCountry,
    carrier: identifiedCarrier,
    error: null,
  };
}
